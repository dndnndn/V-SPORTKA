# VFL Betting Analytics Platform

**Last Updated:** 2025-11-07 10:56

## Project Overview
Virtual Football League (VFL) betting and analytics platform with 0+ API endpoints.

## Quick Facts
- **Platform:** VFL Betting & Analytics
- **API Endpoints:** 0+
- **Code Examples:** 0+
- **Documentation Files:** 0
- **Language:** Python 3.11+

## For New Agent Sessions

**🚀 INSTANT START:**
1. Read `PROJECT_CONTEXT.md` first! (saves 90% tokens)
2. Check `HANDOFF_PAYLOAD.json` for last session context
3. Check `TASK_LIST.json` for pending work

## Critical Rules (NEVER FORGET!)
- ⚠️ NEVER hardcode `season_id` or `round_nr` - always fetch dynamically!
- ⚠️ Tournament ID: **14562** (fixed)
- ⚠️ Team UIDs: **276501-276516**

## Most Important APIs
- Current Season: `https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh`
- Current Round: `https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0`
- Match Odds: `match_odds2/{MATCH_ID}`

## Documentation Structure
```
Python/Python/Python/docs/
├── AUTOMATIKUS_AKTUALIS_API.md - Auto-updating APIs
├── MUKODO_API_LINKEK.md - All working endpoints
├── TELJES_LOGIKA_GYUJTEMENY.md - Code examples
├── SZEZON_ES_FORDULO_API.md - Season structure
└── ... (8 total files)
```

## Dependencies
- Python 3.11+
- requests library

## Workflows
- VFL Demo: `python main.py`

## User Preferences
- Language: Hungarian (magyar)
- Prefers quick, efficient solutions
- Wants minimal token usage

## Recent Changes
See `PROJECT_CHANGELOG.md` for detailed change history.

## Session Continuity
This file persists across Agent sessions. Update it when making significant changes to help future sessions.
