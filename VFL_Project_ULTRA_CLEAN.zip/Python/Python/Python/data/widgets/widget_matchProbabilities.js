SRLive.widget['vswidgets.core.data.matchProbabilities'] = {'setup': {"environment":"Production","dynamicallyOverwrittenUrlCategories":["directFeedUrl","playerclassCdnUrl","scoutUrl","styleUrl","feedUrl"],"useCuDoSS":true,"vfl":{"clientId":569,"clientAlias":"srvirtualgamingvfl","backdoorToken":632421,"scoutUrl":"https:\/\/vfl3mobile.aitcloud.de\/vflbb","feedUrl":"https:\/\/vfl.betradar.com\/ls\/feeds\/","platform":"","sport":"vfl","playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vbl":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":241632,"scoutUrl":"\/\/vbllive.aitcloud.de\/VS2021-02-retail-SciGaming-4digits","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vbl\/feeds\/","styleUrl":"https:\/\/vgskinnings.aitcloud.de\/vbl\/{style}\/css\/vswidgets_vbl{platform}.css","platform":"retail","sport":"vbl","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vto":{"clientId":569,"clientAlias":"srvirtualgamingvto","backdoorToken":241632,"scoutUrl":"https:\/\/vtolive.aitcloud.de\/vto","feedUrl":"https:\/\/vgls.betradar.com\/vto\/feeds\/","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vti":{"clientId":569,"clientAlias":"srvirtualgamingvti","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfec\/mobile","feedUrl":"https:\/\/vglstest.sportradar.ag\/ls\/feeds\/","platform":"","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vfc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfecshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfc{platform}.css","platform":"retail","sport":"vfec","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfnc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfncshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfnc{platform}.css","platform":"retail","sport":"vfnc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfwc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfwcshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfwc{platform}.css","platform":"retail","sport":"vfwc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vflm":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vflmshop","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vflm{platform}.css","platform":"retail","sport":"vflm","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfb":{"clientId":569,"clientAlias":"srvirtualgaming4","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfb","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfb{platform}.css","platform":"","sport":"vfb","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfas":{"clientId":569,"clientAlias":"srvirtualgamingvfas","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfas\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfas{platform}.css","platform":"","sport":"vfas","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfcc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfccshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfcc{platform}.css","platform":"retail","sport":"vfcc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"}}};
(function(SRLive, jQuery, $, undefined) {SRLive.w.define('vswidgets.core.data.matchProbabilities', {
    extend: 'vswidgets.core.data.feed',
    singleton: true,

    /**
     * Request match odds
     */
    matchProbabilities: function(req, res) {
        var self = this;
        var timeline = req.state;

        req.http({
            success: function(result) {
                var data = self.util.extractNode(result.data, 'data');

                //console.log( 'matchProbabilities - Received match odds for', data._id );

                if( !self.vfxutil.isDataValid( data ) ) {
                    console.warn( 'Feed problem: matchProbabilities received no data' );
                    return;
                }

                var handledMatchOdds = self._handleMatchOdds(data, timeline);

                SRLive.poller.request({
                    providerName: self.options.name,
                    feed: 'eventIdsBySeasonAndRound',
                    callback: function (eventIdsResponse) {
                        if( eventIdsResponse.eventIds ) {
                            if (Array.isArray(eventIdsResponse.eventIds[handledMatchOdds.id]) && eventIdsResponse.eventIds[handledMatchOdds.id].length > 1) {
                                var customerMarket = eventIdsResponse.eventIds[handledMatchOdds.id];

                                if( ! customerMarket ) {
                                    console.error( 'Got eventIdsSts response but no eventIds for match id', handledMatchOdds.id, eventIdsResponse );
                                    return;
                                }

                                // to hold customer event IDs found below, will be advised as match property
                                var customerMarketIdsArray = [];

                                // this only needs to be done if there is an eventIdType being sent
                                if (eventIdsResponse.eventIdType && eventIdsResponse.eventIdType == 'matchOddsMarketId'){

                                    // loop over all match markets
                                    for (var i = 0; i < handledMatchOdds.markets.length; i++) {

                                        // loop over customer feed response
                                        for (var j = 0; j < customerMarket.length; j++) {

                                            // no oddsdescription available in match market
                                            if (handledMatchOdds.markets[i].extra === '') {
                                                // look for matching market type and subtype with NO oddsdescription
                                                if ((handledMatchOdds.markets[i].type == customerMarket[j].markettypeid) &&
                                                    (handledMatchOdds.markets[i].subtype == customerMarket[j].marketsubtype) &&
                                                    (null === customerMarket[j].oddsdescription)) {

                                                    // advise the eventid from the customer feed as customerMarketId of this match
                                                    // existing market (will be overwritten later but necessary on start)
                                                    handledMatchOdds.markets[i].customerMarketId = customerMarket[j].eventid;
                                                    // array to be advised to match at the end
                                                    customerMarketIdsArray[i] = customerMarket[j].eventid;
                                                    // and break loop
                                                    break;
                                                }
                                            } else {
                                                // look for matching market type and subtype AND oddsdescription
                                                if ((handledMatchOdds.markets[i].type == customerMarket[j].markettypeid) &&
                                                    (handledMatchOdds.markets[i].subtype == customerMarket[j].marketsubtype) &&
                                                    (handledMatchOdds.markets[i].extra == customerMarket[j].oddsdescription)) {

                                                    // see above
                                                    handledMatchOdds.markets[i].customerMarketId = customerMarket[j].eventid;
                                                    customerMarketIdsArray[i] = customerMarket[j].eventid;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    handledMatchOdds.customerMarketIds = customerMarketIdsArray;
                                }
                            } else {
                                handledMatchOdds.meta.retailEventId = eventIdsResponse.eventIds[handledMatchOdds.id];
                            }
                        }

                        // pass odds overrides
                        self.markets.passOddOverrides(self.options.name, handledMatchOdds.tournament, handledMatchOdds.round, handledMatchOdds.id, [handledMatchOdds], function() {
                            //console.log( 'matchProbabilities - Match odds for match id', handledMatchOdds.id, 'have validity', Math.max(handledMatchOdds.validity, self.Validity.ONE_SECOND)/1000 );
                            res.send(handledMatchOdds, Math.max(handledMatchOdds.validity, self.Validity.ONE_SECOND));
                        });
                    }
                });
            }
        });
    },

    _handleMatchOdds: function(oddsData, timeline) {

        var handledMatch = this.parser.match(oddsData);
        var matchInfo = timeline.getMatchInfo(handledMatch.id);

        var odds = SRUtil.getProperties(oddsData.odds);
        if (odds.length > 0) {
            var betstopValidity = matchInfo && matchInfo.betstopValidity ? matchInfo.betstopValidity : 0;
            handledMatch.markets = this.markets.groupMatchMarketOutcomes(this.options.name, odds, betstopValidity);
            this.markets.enrichMarkets(this.options.name, handledMatch, handledMatch.markets);
            this.markets.addMissingMarkets(this.options.name, handledMatch);
        }
        else {
            // no odds provided for this match, fill with defaults
            handledMatch.markets = this.markets.defaultMarkets(this.options.name, handledMatch);
        }

        // calculate response validity
        handledMatch.validity = 0;
        handledMatch.marketsClosed = true;

        // check if all markets are settled
        for (var i = 0; i < handledMatch.markets.length; i++) {
            if (!handledMatch.markets[i].settled && handledMatch.markets[i].outcomes.length) {
                var market = handledMatch.markets[i];
                if (market.outcomes.length > 0) {
                    for (var j = market.outcomes.length - 1; j >= 0; j--) {
                        var outcome = market.outcomes[j];
                        handledMatch.marketsClosed = (outcome.status === 'open' ? false : true);
                        if (!handledMatch.marketsClosed) { break; }
                    }
                } else {
                    handledMatch.marketsClosed = false;
                }
                if (!handledMatch.marketsClosed) { break; }
            }
        }

        if (handledMatch.marketsClosed) {
            //console.log( 'matchProbabilities - all markets are closed for match id', matchInfo.id );
            // all markets are settled, cache for 24 hours
            handledMatch.validity = this.Validity.ONE_DAY;
        } else if (timeline.isMatchInProgress(handledMatch.id)) {
            // this match is in progress
            handledMatch.validity = Math.min(this.Validity.TEN_SECONDS, timeline.matchCountdown(handledMatch.id) * 1000);
        } else if( timeline.periodId == 'pre_match' || timeline.periodId == 'betstop' ) {
            handledMatch.validity = this.Validity.TEN_SECONDS;
        } else {
            if (handledMatch.marketsClosed && handledMatch.started === true) {
                handledMatch.validity = timeline.shortestCountdown() * 1000;
            } else {
                handledMatch.validity = this.Validity.ONE_SECOND;
            }
        }

        handledMatch.tournament = matchInfo ? matchInfo.tournamentId : undefined;
        handledMatch.round = matchInfo ? (matchInfo.stage + '_' + matchInfo.round) : undefined;

        return handledMatch;
    }
});
})(SRLive, window.SRjQuery || jQuery, window.SRjQuery || jQuery);
