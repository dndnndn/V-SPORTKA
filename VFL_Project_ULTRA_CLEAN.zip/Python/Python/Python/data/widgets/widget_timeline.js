SRLive.widget['vswidgets.vf.timeline'] = {'setup': {"environment":"Production","dynamicallyOverwrittenUrlCategories":["directFeedUrl","playerclassCdnUrl","scoutUrl","styleUrl","feedUrl"],"useCuDoSS":true,"vfl":{"clientId":569,"clientAlias":"srvirtualgamingvfl","backdoorToken":632421,"scoutUrl":"https:\/\/vfl3mobile.aitcloud.de\/vflbb","feedUrl":"https:\/\/vfl.betradar.com\/ls\/feeds\/","platform":"","sport":"vfl","playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vbl":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":241632,"scoutUrl":"\/\/vbllive.aitcloud.de\/VS2021-02-retail-SciGaming-4digits","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vbl\/feeds\/","styleUrl":"https:\/\/vgskinnings.aitcloud.de\/vbl\/{style}\/css\/vswidgets_vbl{platform}.css","platform":"retail","sport":"vbl","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vto":{"clientId":569,"clientAlias":"srvirtualgamingvto","backdoorToken":241632,"scoutUrl":"https:\/\/vtolive.aitcloud.de\/vto","feedUrl":"https:\/\/vgls.betradar.com\/vto\/feeds\/","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vti":{"clientId":569,"clientAlias":"srvirtualgamingvti","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfec\/mobile","feedUrl":"https:\/\/vglstest.sportradar.ag\/ls\/feeds\/","platform":"","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vfc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfecshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfc{platform}.css","platform":"retail","sport":"vfec","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfnc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfncshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfnc{platform}.css","platform":"retail","sport":"vfnc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfwc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfwcshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfwc{platform}.css","platform":"retail","sport":"vfwc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vflm":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vflmshop","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vflm{platform}.css","platform":"retail","sport":"vflm","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfb":{"clientId":569,"clientAlias":"srvirtualgaming4","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfb","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfb{platform}.css","platform":"","sport":"vfb","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfas":{"clientId":569,"clientAlias":"srvirtualgamingvfas","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfas\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfas{platform}.css","platform":"","sport":"vfas","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfcc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfccshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfcc{platform}.css","platform":"retail","sport":"vfcc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"hasOwnCss":false,"jsx":{"main":["createClass({render:function(){return React.createElement(\"div\",{className:\"vsm-timeline-container\"},this.renderEventId(),this.renderTeamNames(),this.renderPreProgressbar(),this.renderTimeline())},renderEventId:function(){if(this.props.showEventId&&this.props.match&&this.props.match.meta)return React.createElement(\"div\",{className:\"vsm-timeline-event-id\"},React.createElement(\"span\",null,this.props.match.meta.retailEventId))},renderTeamNames:function(){if(this.props.match&&this.props.match.home&&this.props.match.away){var e=this.props.showAbbreviations?this.props.match.home.nameShort:this.props.match.home.name,t=this.props.showAbbreviations?this.props.match.away.nameShort:this.props.match.away.name,s=React.createElement(\"img\",{src:this.props.match.home.thumbnail}),a=React.createElement(\"img\",{src:this.props.match.away.thumbnail}),r=\"vsm-timeline-teamnames-home\",n=\"vsm-timeline-teamnames-away\";return this.props.showTeamNames||(r+=\" vsm-timeline-teamnames-noshow\",n+=\" vsm-timeline-teamnames-noshow\",e=null,t=null),this.props.showEventId&&(r+=\" vsm-timeline-has-event-id\",n+=\" vsm-timeline-has-event-id\"),this.props.showFlags||(s=null,a=null),React.createElement(\"div\",{className:\"vsm-timeline-teamnames\"},React.createElement(\"div\",{className:r},React.createElement(\"span\",{className:\"vsm-timeline-teamnames-label\"},s,\"\\xa0\",e,\"\\xa0\")),React.createElement(\"div\",{className:n},React.createElement(\"span\",{className:\"vsm-timeline-teamnames-label\"},a,\"\\xa0\",t,\"\\xa0\")))}},renderPreProgressbar:function(){var e=\"vsm-timeline-progressbar-pre \"+(this.props.showTeamNames?\"\":\"vsm-timeline-teamnames-noshow\")+\" \"+(this.props.showEventId?\"vsm-timeline-has-event-id\":\"\");return this.props.match.match_started&&(e+=\" vsm-timeline-progressbar-finished\"),React.createElement(\"div\",{className:e})},renderFirstHalfProgressbar:function(){var e=\"vsm-timeline-progressbar-firsthalf\";return this.props.match.match_ended||this.props.match.penalty_shootout||this.props.match.overtime||this.props.match.second_period_start?e+=\" vsm-timeline-progressbar-finished\":this.props.match.match_started&&!this.props.match.match_ended&&(e+=\" vsm-timeline-progressbar-progress\"),React.createElement(\"div\",{className:e})},renderSecondHalfProgressbar:function(){var e=\"vsm-timeline-progressbar-secondhalf\";return this.props.match.match_ended||this.props.match.penalty_shootout||this.props.match.overtime?e+=\" vsm-timeline-progressbar-finished\":this.props.match.second_period_start&&!this.props.match.match_ended&&(e+=\" vsm-timeline-progressbar-progress\"),React.createElement(\"div\",{className:e})},renderOvertimeProgressbar:function(){var e=\"vsm-timeline-progressbar-overtime\";return this.props.match.match_ended?this.props.match.overtime&&(e+=\" vsm-timeline-progressbar-finished\"):this.props.match.penalty_shootout?e+=\" vsm-timeline-progressbar-finished\":this.props.match.overtime&&(e+=\" vsm-timeline-progressbar-progress\"),React.createElement(\"div\",{className:e})},renderEventProgressbar:function(){for(var e=this.props.events.length-1,t=null;!t&&e>=0;)this.props.events[e].matchid==this.props.match.id&&(t=this.props.events[e]),e--;if(t){var s=t.time<45?45:90,a=this.props.overtime?90*t.time\/120:t.time,r=null;this.props.match.match_started&&(r=React.createElement(\"div\",{className:\"vsm-timeline-progressbar-past   vsm-timeline-progressbar-finished\",style:{left:0,width:a+\"%\"}}));var n=null;return this.props.match.match_started&&!this.props.match.match_ended&&(n=React.createElement(\"div\",{className:\"vsm-timeline-progressbar-future vsm-timeline-progressbar-progress\",style:{left:a+\"%\",width:s-a+\"%\"}})),React.createElement(\"div\",{className:\"vsm-timeline-progressbar\",style:{width:\"100%\"}},r,n)}},renderProgressbar:function(){return this.props.showEventProgress?this.renderEventProgressbar():React.createElement(\"div\",{className:\"vsm-timeline-progressbar\"},this.renderFirstHalfProgressbar(),this.renderSecondHalfProgressbar(),this.renderOvertimeProgressbar())},renderTimeline:function(){var e=\"vsm-timeline\"+(this.props.showTeamNames?\"\":\" vsm-timeline-teamnames-noshow\")+(this.props.showEventId?\" vsm-timeline-has-event-id\":\"\")+(this.props.match.overtime?\" overtime\":\"\"),t=[];return t.push(this.renderProgressbar()),t.push(this.renderSeparator(0,\"0'\")),t.push(this.renderSeparator(15)),t.push(this.renderSeparator(30)),t.push(this.renderSeparator(45,\"45'\")),t.push(this.renderSeparator(60)),t.push(this.renderSeparator(75)),t.push(this.renderSeparator(90,\"90\")),t.push(this.renderSeparator(105)),t.push(this.renderSeparator(120,\"120'\")),this.props.showPenaltybox&&t.push(this.renderPenaltyBox()),t.push(this.renderEventTracks(this.props.events)),React.createElement(\"div\",{className:e},t)},renderSeparator:function(e,t){var s=\"vsm-timeline-separator vsm-timeline-separator-\"+e;return React.createElement(\"div\",{className:s,key:e},React.createElement(\"span\",{className:\"vsm-timeline-seperator-label\"},t))},renderEventTracks:function(e){for(var t={home:[],away:[],none:[]},s=0;s<e.length;s++){var a=e[s];a._typeid!=SREnum.eventTypeId.penalties_start&&(a.matchid==this.props.match.id&&t[a.team].push(a))}for(var r=[],n=Object.keys(t),i=0;i<n.length;i++){var m=t[n[i]];r=r.concat(this.renderEvents(m))}return r},renderEvents:function(e){for(var t=[],s=[],a=null,r=0;r<e.length;r++){var n=e[r];if(!n.penalty_shootout||n._typeid!=SREnum.eventTypeId.goal&&n._typeid!=SREnum.eventTypeId.penalty_missed)if(!a||n.time>=a.firstEvent.time+this.props.minimumTimeDistance){var i={events:[n],mainEvent:n,firstEvent:n};s.push(i),a=i}else a.events.push(n),n.priority<a.mainEvent.priority&&(a.mainEvent=n)}for(r=0;r<s.length;r++){i=s[r];var m=\"eventGroup_\"+this.props.match.id+\"_\"+i.mainEvent._id,o=\"eventGroupInfo_\"+this.props.match.id+\"_\"+i.mainEvent._id;t.push(this.renderEventGroup(i,m,o)),\"none\"!=i.mainEvent.team&&t.push(this.renderEventGroupInfo(i,o))}return t},renderEventGroup:function(e,t,s){var a=\"vsm-none\",r=e.mainEvent,n=e.firstEvent,i=[];i[SREnum.eventTypeId.goal]=\"goal\",i[SREnum.eventTypeId.yellow_card]=\"card\",i[SREnum.eventTypeId.yellow_red_card]=\"card\",i[SREnum.eventTypeId.red_card]=\"card\",i[SREnum.eventTypeId.first_extra_period_start]=\"\",i[SREnum.eventTypeId.second_period_start]=\"whistle\",i[SREnum.eventTypeId.normal_time_score]=\"\",i[SREnum.eventTypeId.match_started]=\"match_started\",i[SREnum.eventTypeId.match_ended]=\"match_ended\",i[SREnum.eventTypeId.penalty_missed]=\"\",i[SREnum.eventTypeId.second_extra_period_start]=\"\",i[SREnum.eventTypeId.penalties_start]=\"\",i[SREnum.eventTypeId.score_after_extra_time]=\"\",i[SREnum.eventTypeId.score_after_penalties]=\"\";var m=\"vsm-icon\";i[r._typeid]?m+=\" vsm-icon-\"+i[r._typeid]:void 0===i[r._typeid]&&console.log(\"unknown event type\",r._typeid,r.type);var o=n.time;this.props.overtime&&(o=90*o\/120),r.team&&(a=\"vsm-\"+r.team),r._typeid==SREnum.eventTypeId.red_card?m+=\" vsm-card-red\":r._typeid==SREnum.eventTypeId.yellow_card?m+=\" vsm-card-yellow\":r._typeid==SREnum.eventTypeId.yellow_red_card?m+=\" vsm-card-yellowred\":r._typeid==SREnum.eventTypeId.goal&&r.owngoal?m+=\" vsm-goal-owngoal\":r._typeid==SREnum.eventTypeId.first_extra_period_start&&(m=\"vsm-icon vsm-icon-overtime\");var p=\"vsm-timeline-event \"+a,l=m+\" vsm-new\",c=e.events.length>1?\"inline\":\"none\",h=function(e){SRjQuery(\"#\"+s).show()},v=function(e){SRjQuery(\"#\"+s).hide()};return\"none\"===r.team&&(h=null,v=null),React.createElement(\"div\",{className:p,style:{left:o+\"%\"},key:\"event_\"+r._id,onMouseEnter:h,onMouseLeave:v},React.createElement(\"span\",{className:\"vsm-timeline-multievent\",style:{display:c}},\"+\"),React.createElement(\"span\",{id:t,className:l}))},renderEventGroupInfo:function(e,t){var s=[],a=\"vsm-timeline-event-details\";a+=\" \"+e.mainEvent.team,a+=\" \"+(this.props.eventInfoPosition||\"bottom\");var r={display:\"none\"},n=e.firstEvent.time;this.props.overtime&&(n=90*n\/120);var i=0,m=this.props.platform[1];(\"top\"===this.props.eventInfoPosition&&e.events.length>1||\"extrasmall\"===m)&&(i=this.props.minimumTimeDistance\/2);var o=this.props.overtime?60:45;e.firstEvent.time<=o?(r.left=n+i,r.left+=\"%\"):(r.right=100-n+i,r.right+=\"%\");for(var p=0;p<e.events.length;p++){var l=e.events[p],c=\"vsm-timeline-event-table-time vsm-\"+l.team,h=null;(l.player&&void 0===this.props.showPlayerName||this.props.showPlayerName)&&(h=React.createElement(\"div\",{className:\"vsm-timeline-event-table-player\"},l.player.name)),s.push(React.createElement(\"tr\",{key:p},React.createElement(\"td\",{className:c},React.createElement(\"span\",null,l.time,\"'\")),React.createElement(\"td\",null,React.createElement(\"div\",{className:\"vsm-timeline-event-table-name\"},this.t(l.type)),h)))}return React.createElement(\"div\",{id:t,key:t,className:a,style:r},React.createElement(\"table\",{className:\"vsm-timeline-event-table\"},React.createElement(\"tbody\",null,s)))},renderPenaltyBox:function(){if(this.props.penalty_shootout)return React.createElement(\"div\",{className:\"vsm-timeline-penaltybox vsm-timeline-penaltybox-show\",style:{display:\"block\"}},React.createElement(\"div\",{className:\"vsm-timeline-penalty-goal\",style:{display:this.props.match.match_ended?\"none\":\"block\"}},React.createElement(\"span\",{className:\"vsm-icon vsm-icon-penalty\"}),React.createElement(\"span\",{className:\"vsm-icon-penalty-background\"})),React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-home\"},React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-home-score\"},this.props.penalties.home[0]),\"\/\",React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-home-missed\"},this.props.penalties.home[1])),React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-away\"},React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-away-score\"},this.props.penalties.away[0]),\"\/\",React.createElement(\"span\",{className:\"vsm-timeline-penaltybox-away-missed\"},this.props.penalties.away[1])))}})"]},"strings":{"match_started":"Match started","match_ended":"\u6bd4\u8d5b\u5b8c\u7ed3","second_period_start":"Second period start","first_extra_period_start":"First extra period start","penalties_start":"Penalties start","goal":"\u8fdb\u7403","normal_time_score":"Normal time score","score_after_extra_time":"Score after extra time","score_after_penalties":"Score after penalties","yellow_card":"\u9ec4\u724c","yellow_red_card":"\u9ec4\u7ea2\u724c","red_card":"\u7ea2\u724c","penalty_missed":"Penalty missed"}}};
(function(SRLive, jQuery, $, undefined) {SRLive.w.define('vswidgets.vf.timeline', {
    extend: 'vswidgets.core.timeline-base',

    // reference for react-template
    template: null,

    directLiveEventsHandle: null,
    timelineHandle: null,
    timelineData: null,

    subscribeToDirectLiveEventsTimeoutHandler: null,

    match: null,
    currentMatchId: null,
    oldMatchId: null,

    matches: [],
    matchesById: {},

    events: [],
    eventsById: {},

    teamInformation: {},
    playerInformation: {},

    matchManager: null,

    options: {
        selectedChannel: 0,
        showEventProgress: true,
        minimumPixelDistance: 20,
        height: '60px',
        showFlags: false,
        showTeamNames: true,
        showAbbreviations: true,
        //showEventsIds: true,
        eventInfoPosition: 'top',
        maxNumberOfPenalties: 5, // max 6 if there's a draw after 5 shoot outs
        showPenaltybox: false
    },

    minimumTimeDistance: 5,

    enabledEvents : [
        SREnum.eventTypeId.red_card,
        SREnum.eventTypeId.yellow_card,
        SREnum.eventTypeId.yellow_red_card,
        SREnum.eventTypeId.goal,
        SREnum.eventTypeId.match_started,
        SREnum.eventTypeId.second_period_start,
        SREnum.eventTypeId.match_ended,
        //SREnum.eventTypeId.score_after_extra_time,
        //SREnum.eventTypeId.score_after_penalties,
        SREnum.eventTypeId.penalties_start,
        SREnum.eventTypeId.first_extra_period_start,
        //SREnum.eventTypeId.normal_time_score,
        SREnum.eventTypeId.penalty_missed
    ],

    constructor: function() {
        this.applySuper('constructor', arguments);

        if( ! this.options.selectedChannel ) {
            this.options.selectedChannel = 0;
        }

        // Turn off this event
        this.offPublic( 'match_selected' );

        var self = this;
        this._getProvider().loadMatchManager(
            {
                widgetGroup: this.options.widgetGroup
            },
            function( component ) {
                self.matchManager = component;
                self.setChannel( self.options.selectedChannel );
            }
        );

        this.onPublic( 'vswidgets/' + this._getSportId() + '/matchmanager/channel_switch', function( event ) {
            self.setChannel( event );
        }.bind(this));

        this.onPublic( 'vswidgets/' + this._getSportId() + '/matchmanager/chunk_switch', function( event ) {
            self.setChannel( event );
        }.bind(this));

        this.optionsForSetters.showEventProgress = this.validators.assertTrue.bind(this);
        this.optionsForSetters.minimumPixelDistance = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showPlayerName = this.validators.assertTrue.bind(this);

        // when window size changes, render
        SRjQuery(window).on( 'resize', this.calculateMinimumTimeDistance.bind(this) );
    },

    /**
     * Renders the JSX template, then calls calculateMinimumTimeDistance()
     */
    render: function() {
        var container = this.getContainer();
        if( container.length && this.view && this.timelineData && this.match ) {

            // define props that are expected from the template
            var props = {
                eventInfoPosition: this.options.eventInfoPosition,
                events: this.events,
                match: this.match,
                minimumPixelDistance: this.options.minimumPixelDistance,
                minimumTimeDistance: this.minimumTimeDistance,
                overtime: this.match.overtime,
                penalties: this.match.penalties,
                penalty_shootout: this.match.penalty_shootout,
                phase: this.timelineData.channels[this.matchManager.selectedMatchIndex].phase,
                platform: this.options.platform,
                showAbbreviations: this.options.showAbbreviations,
                showEventId: this.options.showEventId,
                showEventProgress: this.options.showEventProgress,
                showTeamNames: this.options.showTeamNames,
                showFlags: this.options.showFlags,
                showPenaltybox: this.options.showPenaltybox,
                showPlayerName: this.options.showPlayerName
            };
            if(!this.template) {
                // initialise template with that props initially
                this.view.renderJsx({
                    container: container,
                    template: 'main',
                    doc: props
                });
            }else {
                // render template via setProps with that props later on
                this.template.setProps(props);
            }

            this.calculateMinimumTimeDistance();
        }
    },

    /**
     * Calculates minimumTimeDistance between events and re-renders if necessary
     */
    calculateMinimumTimeDistance: function() {
        var timelineWidth = this.getContainer().find('.vsm-timeline-progressbar').width();
        if( timelineWidth && this.options.minimumPixelDistance ) {
            var matchLength = this.overtime ? 120 : 90;
            var minimumTimeDistance = Math.ceil( matchLength / timelineWidth * this.options.minimumPixelDistance );
            if( minimumTimeDistance != this.minimumTimeDistance ) {
                this.minimumTimeDistance = minimumTimeDistance;
                this.render();
            }
        }
    },

    /**
     * Clears stored events and subscribes to events for the given match
     */
    subscribeToMatchEvents: function(matchData) {
        if (!matchData || !matchData.id) {
            return;
        }

        this.render();
        if( this.timelineData && ! this.directLiveEventsHandle ) {
            this.subscribeToDirectLiveEvents();
        }
    },

    /**
     * Subscribe to Timeline feed
     */
    startPolling: function(){
        var self = this;

        SRLive.poller.request({
            providerName: this.providerName,
            feed: 'teamInformation',
            callback: function( teamInformation ) {
                self.teamInformation = teamInformation;

                SRLive.poller.request({
                    providerName: self.providerName,
                    feed: 'playerInformation',
                    callback: function( playerInformation ) {
                        self.playerInformation = playerInformation;

                        if( self.timelineHandle ) {
                            SRLive.poller.unsubscribe( self.timelineHandle );
                            self.timelineHandle = null;
                        }

                        self.timelineHandle = SRLive.poller.subscribe({
                            providerName: self.providerName,
                            feed: (self.providerName == 'vfb' || self.providerName == 'vflm') ? 'realTimeline' : 'timeline',
                            callback: self.processTimeline.bind( self )
                        });
                    }
                });
            }
        });
    },

    /**
     * Handle Timeline feed response
     */
    processTimeline: function( data ) {
        if( !data ) {
            console.warn( 'Timeline data is empty' );
            return;
        }

        if( this.timelineData ) {
            var firstMatch = this.timelineData.channels[0].matches[0];
            var newFirstMatch = data.channels[0].matches[0];
            if( firstMatch.id != newFirstMatch.id ) {
                this.currentMatchId = newFirstMatch.id;
                this.events = [];
                this.eventsById = {};
            }
        }

        this.timelineData = data;

        // Store current matches
        // Also, clear old unused match status entries, but keep entries for current matches.
        var oldMatchesById = this.matchesById;
        this.matchesById = {};
        this.matches = [];
        for( var i = 0; i < data.channels.length; i++ ) {

            var matchData = data.channels[i].matches[0];
            var match = oldMatchesById[matchData.id];

            // Unknown match? Create it
            if( ! match ) {
                match = SRjQuery.extend( {}, data.channels[i].matches[0] );
                match.meta = {};
                match.home = this.teamInformation[match.home_team_id];
                match.away = this.teamInformation[match.away_team_id];
                match.match_started = false;
                match.second_period_start = false;
                match.overtime = false;
                match.penalty_shootout = false;
                match.match_ended = false;
                match.penalties = {
                    home: [0, 0],
                    away: [0, 0]
                };
            }

            // Store match
            this.matches.push( match );
            this.matchesById[match.id] = match;
        }

        if( !this.match || !this.matchesById[this.match.id] ) {
            this.setChannel( this.options.selectedChannel );
        }
        this.render();
    },

    /**
     * Subscribe to DirectLiveEventsFeed; calls processDirectLiveEvents() with responses
     */
    subscribeToDirectLiveEvents: function() {
        if ( !SRLive || !SRLive.poller ) {
            return;
        }
        var self = this;

        // This is not a real subscription; instead, we request the event feed with new arguments after every response
        // This way, we can add the last event id with every request, and also don't need to resubscribe in a new chunk
        this.directLiveEventsHandle = SRLive.poller.request({
            providerName: this.providerName,
            feed: 'rawDirectLiveEvents',
            callback: function(data, meta) {
                if( data.data ) {
                    data = data.data;
                }
                self.processDirectLiveEvents( data );

                // while widget is running, poll again (pseudo-subscription)
                if( !self._widget || (self._widget && self._widget.status != 'DESTROYED')) {
                    var validity = meta.expirationTime-new Date();
                    self.subscribeToDirectLiveEventsTimeoutHandler = setTimeout(
                        !self._widget || (self._widget && self._widget.status != 'DESTROYED') ? self.subscribeToDirectLiveEvents.bind(self) : function() {},
                        validity
                    );
                }
            }
        });
    },

    unsubscribeToDirectLiveEvents: function() {
        clearTimeout(this.subscribeToDirectLiveEventsTimeoutHandler);
        this.directLiveEventsHandle = null;
        this.subscribeToDirectLiveEventsTimeoutHandler = null;
    },

    /**
     * Handle response from the DirectLiveEvents feed and calls render()
     */
    processDirectLiveEvents: function( data ) {
        if( data.data ) {
            data = data.data;
        }
        if( data.events && data.events.length && this.currentMatchId === this.oldMatchId) {
            for( var i = 0; i < data.events.length; i++ ) {
                var event = SRjQuery.extend( {}, data.events[i] );
                // Only process enabled events
                if (SRjQuery.inArray( event._typeid, this.enabledEvents) != -1 ) {
                    // Only process new events
                    if( ! this.eventsById[event._id]) {
                        this.events.push( event );
                        this.eventsById[event._id] = event;
                        this.processEvent( event );
                    }
                }
            }
            this.render();
        } else {
            // This fixes a race condition where the live events of an old match would be put into the live events
            // of an current match after they have been reset.
            this.oldMatchId = this.currentMatchId;
        }
    },

    /**
     * Handle response for a single entry from the DirectLiveEventsFeed
     */
    processEvent: function( matchEvent ) {

        matchEvent.priority = this.getEventPriority( { typeId: matchEvent._typeid } );

        if( !matchEvent.team ) {
            matchEvent.team = 'none';
        }

        if( matchEvent.player ) {
            matchEvent.player = this.playerInformation[matchEvent.player._id] || { name: 'Player #' + matchEvent.player._id };
        }

        var match = this.matchesById[matchEvent.matchid];
        if( ! match ) {
            // FIXME this happens way too often
            //console.warn( 'no match for event', matchEvent, 'matches are', Object.keys(this.matchesById) );
            return;
        }

        var eventId = parseInt(matchEvent._typeid);
        switch(eventId) {
            case SREnum.eventTypeId.match_started:
                match.match_started = true;
                break;

            case SREnum.eventTypeId.goal:
                if( match[matchEvent.team].id != matchEvent.player.teamid ) {
                    matchEvent.owngoal = true;
                }
                if (match.penalty_shootout && matchEvent.time > 120) {
                    match.penalties[matchEvent.team][0]++;
                    match.penalties[matchEvent.team][1]++;
                }
                break;

            case SREnum.eventTypeId.second_period_start:
                match.second_period_start = true;
                break;

            case SREnum.eventTypeId.first_extra_period_start:
                match.overtime = true;
                break;

            case SREnum.eventTypeId.penalties_start:
                match.penalty_shootout = true;
                break;

            case SREnum.eventTypeId.penalty_missed:
                // Beware: this event is also fired for foul penalties during normal match time
                if( match.penalty_shootout ) {
                    match.penalties[matchEvent.team][1]++;
                }
                break;

            case SREnum.eventTypeId.match_ended:
                match.match_ended = true;
                break;
        }

        if( match.overtime ) {
            matchEvent.overtime = true;
        }
        if( match.penalty_shootout ) {
            matchEvent.penalty_shootout = true;
        }
    },

    /**
     * Sets the current channel by accepting an event object. Automatically called in case of a match_selected event.
     */
    selectMatch: function( object ) {
        if( typeof object === 'object' ) {
            object = object.selectedChannel;
        }
        if( typeof object === 'undefined' ) {
            object = this.options.selectedChannel;
        }
        this.setChannel( object );
    },

    /**
     * Set the current channel and automatically selects the correct match.
     */
    setChannel: function( newChannel ) {
        var self = this;

        this.options.selectedChannel = newChannel;

        if( this.matches && this.matchManager ) {
            // save current match
            this.match = this.matches[this.matchManager.selectedMatchIndex];
            this.checkRetailId( this.match, function(match) {
                self.subscribeToMatchEvents(match);
                self.render();
            });
        }
    },

    /**
     * If showEventId is set, retrieves event ids for the current match. Finishes by calling the callback.
     */
    checkRetailId: function(match, callback) {
        if (!this.options.showEventId || ! this.timelineData) {
            callback(match);
            return;
        }
        var self = this;

        var args = {
            tournament: this.timelineData.tournament.id,
            stagetype: this.timelineData.stageId,
            round: this.timelineData.round
        };

        SRLive.poller.request({
            providerName: this.providerName,
            feed: 'eventIdsBySeasonAndRound',
            args: args,
            callback: function(eventIdsResponse) {
                if( self.match.id == match.id ) {
                    self.match.meta.retailEventId = eventIdsResponse.eventIds[match.id];
                }
                callback( match );
            }
        });
    },

    /**
     * Appends setChannel() and setSelectedChannel() to the public API
     */
    publicAPI: function() {
        var api = this.applySuper( 'publicAPI' );
        api.setChannel = this.setChannel.bind(this);
        api.setSelectedChannel = this.setChannel.bind(this);
        return api;
    }
});
})(SRLive, window.SRjQuery || jQuery, window.SRjQuery || jQuery);
