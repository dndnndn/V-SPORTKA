SRLive.widget['vswidgets.vfc.results'] = {'setup': {"environment":"Production","dynamicallyOverwrittenUrlCategories":["directFeedUrl","playerclassCdnUrl","scoutUrl","styleUrl","feedUrl"],"useCuDoSS":true,"vfl":{"clientId":569,"clientAlias":"srvirtualgamingvfl","backdoorToken":632421,"scoutUrl":"https:\/\/vfl3mobile.aitcloud.de\/vflbb","feedUrl":"https:\/\/vfl.betradar.com\/ls\/feeds\/","platform":"","sport":"vfl","playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vbl":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":241632,"scoutUrl":"\/\/vbllive.aitcloud.de\/VS2021-02-retail-SciGaming-4digits","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vbl\/feeds\/","styleUrl":"https:\/\/vgskinnings.aitcloud.de\/vbl\/{style}\/css\/vswidgets_vbl{platform}.css","platform":"retail","sport":"vbl","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vto":{"clientId":569,"clientAlias":"srvirtualgamingvto","backdoorToken":241632,"scoutUrl":"https:\/\/vtolive.aitcloud.de\/vto","feedUrl":"https:\/\/vgls.betradar.com\/vto\/feeds\/","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vti":{"clientId":569,"clientAlias":"srvirtualgamingvti","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfec\/mobile","feedUrl":"https:\/\/vglstest.sportradar.ag\/ls\/feeds\/","platform":"","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vfc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfecshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfc{platform}.css","platform":"retail","sport":"vfec","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfnc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfncshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfnc{platform}.css","platform":"retail","sport":"vfnc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfwc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfwcshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfwc{platform}.css","platform":"retail","sport":"vfwc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vflm":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vflmshop","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vflm{platform}.css","platform":"retail","sport":"vflm","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfb":{"clientId":569,"clientAlias":"srvirtualgaming4","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfb","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfb{platform}.css","platform":"","sport":"vfb","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfas":{"clientId":569,"clientAlias":"srvirtualgamingvfas","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfas\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfas{platform}.css","platform":"","sport":"vfas","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfcc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfccshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfcc{platform}.css","platform":"retail","sport":"vfcc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"hasOwnCss":false,"jsx":{"main":["createClass({render:function(){var e=void 0!==this.props.data.matches&&this.props.data.matches.length>0?\"\":\"not-started\",t=void 0!==this.props.data.matches&&this.props.data.matches.length>0?\"\":\"- \"+this.t(\"not_started\")+\" -\";return React.createElement(\"div\",{className:\"vsm-vfc-results-container-outer\",style:this._getWidgetHeight()},this._getResultsGroupHeader(),React.createElement(\"div\",{className:\"vsm-vfc-results-data-container \"+e},t,React.createElement(\"div\",{className:this._getResultsTableContainerClass(),style:this.props.tableRowStyles.tableContainerStyle},React.createElement(\"div\",{className:\"vsm-vfc-results-table\"},this._getResultsGroupRows()))))},update:function(e,t,s,a,r){try{this.props.data.group.letter!==e.group.letter||s?this.adjustHeight=!0:this.adjustHeight=!1;var o=this.props;if(o.data=e,\"#prematchGroupResultWidget\"==o.options.container)try{o.options.group=o.liveScoreMatches[Object.keys(o.liveScoreMatches)[0]].group.letter}catch(e){}o.liveScoreMatches=a,o.activeMatchId=r,this.setProps(o)}catch(e){}},_getResultsTableContainerClass:function(){return this.props.options.groupActive&&this.props.options.showActiveGroupBorder?\"vsm-vfc-results-table-container vsm-vfc-results-table-container-active\":\"vsm-vfc-results-table-container\"},_getWidgetHeight:function(){var e;return\"resultsGroup\"==this.props.widgetType&&\"retail\"==this.props.options.platform[0]&&2==this.props.options.platform.length?(this.props.options.height=810,e=this.props.options.height+\"px\"):e=\"resultsKnockout\"==this.props.widgetType||\"resultsLeague\"==this.props.widgetType?\"100%\":parseInt(this.props.options.height)+\"px\",{height:e}},_getResultsGroupHeader:function(){var e=\"\";try{e=\"resultsKnockout\"==this.props.widgetType||\"resultsLeague\"==this.props.widgetType?this.props.data.roundName:this.props.data.group.name}catch(e){}if(this.props.options.showHeader){var t=this.props.options.groupActive&&this.props.options.showActiveGroupBorder?\"vsm-vfc-results-group vsm-vfc-results-group-active\":\"vsm-vfc-results-group\";if(\"resultsGroup\"!=this.props.widgetType)var s={height:this.props.options.headerHeight};else s=this.props.tableRowStyles.headerContainerStyle||{};return React.createElement(\"div\",{className:\"vsm-vfc-results-heading\",style:s},React.createElement(\"div\",{className:t},React.createElement(\"span\",null,e)))}return\"\"},_getResultsGroupRows:function(){var e,t=[[]],s=0,a=0;this.props.options.timelineChannels;if(this.props.data.matches)for(var r=0;r<this.props.data.matches.length;r++){e=this.props.data.matches[r];var o=!1;if(this.props.options.filterTeams&&\"object\"==typeof this.props.options.filterTeams&&this.props.options.filterTeams.length>=1)for(var i in o=!0,this.props.options.filterTeams){var l=this.props.options.filterTeams[i];parseInt(l)!==parseInt(e.home.uid)&&parseInt(l)!==parseInt(e.away.uid)||(o=!1)}if(!o){var p=r%2==0&&r!==this.props.data.matches.length-1;t[s].push(this._getResultRowData(e,p));var h=2;this.props.data.group&&!0===this.props.data.group.league&&(h=1,$(\".vfc-vsm-vfc-results-table-data-home .img\").css(\"height\",\"16px\"),$(\".vfc-vsm-vfc-results-table-data-away .img\").css(\"height\",\"16px\")),r%h==1&&r!==this.props.data.matches.length-1&&(t.push([]),s++)}}return t.map((function(e){return a++,React.createElement(\"div\",{key:\"group=\"+a,className:\"vfc-vsm-vfc-results-table-tbody\"},e)}))},_getResultRowData:function(e,t){var s,a,r,o=this.props.options.switchTeams?e.away:e.home,i=this.props.options.switchTeams?e.home:e.away,l={};if(\"resultsGroup\"!=this.props.widgetType&&\"resultsLeague\"!=this.props.widgetType?(l.height=this.props.options.rowHeight,l.lineHeight=this.props.options.rowHeight,r={height:this.props.options.rowHeight,lineHeight:this.props.options.rowHeight}):\"resultsGroup\"!=this.props.widgetType&&\"resultsLeague\"==this.props.widgetType?(l.height=this.props.options.rowHeight,r={height:this.props.options.rowHeight}):r={},this.props.options.showMatchIds||this.props.options.showApprovalCode){var p=\"resultsKnockout\"!==this.props.widgetType&&\"resultsLeague\"!==this.props.widgetType||!e.meta.retailEventId||\"\"===e.meta.retailEventId?e.meta&&e.meta.avv?e.meta.avv:this.props.italianMarket?\"-\":e.id:e.meta.retailEventId,h=this.props.options.approvalCodeLabel?this.props.options.approvalCodeLabel:\"\";s=this.props.options.showMatchIds?React.createElement(\"div\",{className:\"vsm-vfc-results-retail-table-id\",style:r},React.createElement(\"div\",null,React.createElement(\"span\",null,p))):React.createElement(\"div\",{className:\"vsm-vfc-results-retail-table-id\",style:r},React.createElement(\"div\",{className:\"vsm-vfc-results-retail-match-label\"},h),React.createElement(\"div\",{className:\"vsm-vfc-results-retail-match-id\"},p)),a=80}else a=100;l.width=a+\"%\";var n=\"vfc-vsm-vfc-results-table-row\";e.id==this.props.activeMatchId&&(n+=\" active-match\");var c=t?this.props.tableRowStyles.actualRowHeightEvenStyles:this.props.tableRowStyles.actualRowHeightOddStyles;return React.createElement(\"div\",{key:\"matchId=\"+e.id,className:n,style:c},s,React.createElement(\"div\",{className:\"vfc-vsm-vfc-results-retail-table-data-container\",style:l},this._getTeamRowData(o,\"home\"),this._getRowScore(e,o,i),this._getTeamRowData(i,\"away\")))},_getRowScore:function(e,t,s){var a,r=!1;if(e.started){var o=this._getMatchScore(e),i=\"\";if(\"resultsGroup\"!=this.props.widgetType){var l=!!(e&&e.phase&&\"penalty_shootout\"===e.phase||e.periodResults&&4===e.periodResults.home.length&&4===e.periodResults.away.length&&e.matchStatus===SREnum.matchStatusId.ended||e.periodResults&&3===e.periodResults.home.length&&3===e.periodResults.away.length&&e.matchStatus!==SREnum.matchStatusId.ended||e&&e.phase&&\"post_match\"===e.phase&&e.periodResults&&4===e.periodResults.home.length&&4===e.periodResults.away.length),p=!!(e&&e.phase&&\"overtime\"===e.phase||e.periodResults&&3===e.periodResults.home.length&&3===e.periodResults.away.length&&e.matchStatus===SREnum.matchStatusId.ended||e.periodResults&&2===e.periodResults.home.length&&2===e.periodResults.away.length&&e.matchStatus!==SREnum.matchStatusId.ended||e&&e.phase&&\"post_match\"===e.phase&&e.periodResults&&3===e.periodResults.home.length&&3===e.periodResults.away.length&&\"\"===inPenalties);70===e.matchStatus&&(l=!1,p=!1);var h=p?this.renderOvertime(e,o):\"\",n=l?this.renderPenalties(e,o):\"\";p?i=h:l&&(i=n),\"\"!==o.homeHT&&\"\"!==o.awayHT&&(a=this.props.options.showHalftimeScoreParenthesized?React.createElement(\"span\",{key:e.id+\"-score-ht\",className:\"vsm-vfc-results-halftime-result\"},\"(\",o.homeHT,\":\",o.awayHT,\")\"):React.createElement(\"span\",{key:e.id+\"-score-ht\",className:\"vsm-vfc-results-halftime-result\"},o.homeHT,\":\",o.awayHT))}else\"\"===o.homeHT&&(o.homeHT=0),\"\"===o.awayHT&&(o.awayHT=0),a=this.props.options.showHalftimeScoreParenthesized?React.createElement(\"span\",{key:e.id+\"-score-ht\",className:\"vsm-vfc-results-halftime-result\"},\"(\",o.homeHT,\":\",o.awayHT,\")\"):React.createElement(\"span\",{key:e.id+\"-score-ht\",className:\"vsm-vfc-results-halftime-result\"},o.homeHT,\":\",o.awayHT);r=[i,React.createElement(\"span\",{key:e.id+\"-score-ft\",className:\"vsm-vfc-results-fulltime-result\"},o.homeFT,\":\",o.awayFT),a]}else{var c=this._getMatchStartTime(e),m=this.props.options.showWhistleIcon?React.createElement(\"span\",{className:\"vsm-icon-whistle\"}):\"\";r=React.createElement(\"span\",{className:\"vsm-vfc-results-matchstart\"},m,\" \",c.hourStart,\":\",c.minutesStart)}return React.createElement(\"div\",{className:\"vfc-vsm-vfc-results-table-data-result\"},r)},renderOvertime:function(e,t){var s=this.props.options.overtimePenaltyIcon?this.renderOvertimeIcon():\"\";return React.createElement(\"span\",{key:e.id+\"-score-ot\",className:\"vsm-vfc-results-overtime-result\"},s,t.homeOver+t.homeFT,\":\",t.awayOver+t.awayFT)},renderPenalties:function(e,t){var s=this.props.options.overtimePenaltyIcon?this.renderPenaltiesIcon():\"\";return React.createElement(\"span\",{key:e.id+\"-score-pt\",className:\"vsm-vfc-results-penalties-result\"},s,t.homePenalties+t.homeOver+t.homeFT,\":\",t.awayPenalties+t.awayOver+t.awayFT)},renderOvertimeIcon:function(){return React.createElement(\"div\",{className:\"vsm-vfc-results-overtime-icon-wrap\"},React.createElement(\"span\",{className:\"vsm-icon-overtime vsm-icon\"}))},renderPenaltiesIcon:function(){return React.createElement(\"div\",{className:\"vsm-vfc-results-penalties-icon-wrap\"},React.createElement(\"span\",{className:\"vsm-icon vsm-icon-goal\"}),React.createElement(\"span\",{className:\"vsm-icon vsm-penalty-goal-coaster\"}))},_getMatchScore:function(e){var t=this.props.options.switchTeams?e.formatedResults.away.full:e.formatedResults.home.full,s=this.props.options.switchTeams?e.formatedResults.home.full:e.formatedResults.away.full,a=this.props.options.switchTeams?e.formatedResults.away.half:e.formatedResults.home.half,r=this.props.options.switchTeams?e.formatedResults.home.half:e.formatedResults.away.half,o=this.props.options.switchTeams?e.formatedResults.away.over:e.formatedResults.home.over,i=this.props.options.switchTeams?e.formatedResults.home.over:e.formatedResults.away.over,l=this.props.options.switchTeams?e.formatedResults.away.penalties:e.formatedResults.home.penalties,p=this.props.options.switchTeams?e.formatedResults.home.penalties:e.formatedResults.away.penalties;if(this.props.liveScoreMatches){var h=this.props.liveScoreMatches,n=e.id;if(n in h)t=this.props.options.switchTeams?h[n].formatedResults.away.full:h[n].formatedResults.home.full,s=this.props.options.switchTeams?h[n].formatedResults.home.full:h[n].formatedResults.away.full,a=this.props.options.switchTeams?h[n].formatedResults.away.half:h[n].formatedResults.home.half,r=this.props.options.switchTeams?h[n].formatedResults.home.half:h[n].formatedResults.away.half,o=this.props.options.switchTeams?h[n].formatedResults.away.over:h[n].formatedResults.home.over,i=this.props.options.switchTeams?h[n].formatedResults.home.over:h[n].formatedResults.away.over,l=this.props.options.switchTeams?h[n].formatedResults.away.penalties:h[n].formatedResults.home.penalties,p=this.props.options.switchTeams?h[n].formatedResults.home.penalties:h[n].formatedResults.away.penalties}return{homeFT:t,awayFT:s,homeHT:a,awayHT:r,homeOver:o,awayOver:i,homePenalties:l,awayPenalties:p}},_getMatchStartTime:function(e){var t=new Date(1e3*e.startsAt),s=t.getHours(),a=t.getMinutes();return{hourStart:s<10?\"0\"+s:s,minutesStart:a<10?\"0\"+a:a}},_getTeamRowData:function(e,t){var s=this.props.options.showTeamAbbr?e.nameShort:e.name;return\"away\"===t?React.createElement(\"div\",{className:\"vfc-vsm-vfc-results-table-data-\"+t},this._getFlag(e,t),React.createElement(\"span\",{className:\"vfc-results-teamname-\"+t},React.createElement(\"span\",null,s))):React.createElement(\"div\",{className:\"vfc-vsm-vfc-results-table-data-\"+t},React.createElement(\"span\",{className:\"vfc-results-teamname-\"+t},React.createElement(\"span\",null,s)),this._getFlag(e,t))},_getFlag:function(e,t){return this.props.options.showFlags?React.createElement(\"span\",{className:\"vfc-results-country-flag-\"+t},React.createElement(\"img\",{src:e.thumbnail})):\"\"}})"]},"strings":{"not_started":"Nem kezd\u0151d\u00f6tt el"}}};
(function(SRLive, jQuery, $, undefined) {/* global SRReact, React, SRjQuery, SRVsmUtil */
SRLive.w.define('vswidgets.vfc.results', {
    extend: 'vswidgets.core.basecomponent',

    options: {
        height: '400px',
        showHeader: true,
        showActiveGroupBorder: true,
        showFlags: true,
        group: 'A',
        subscribeToLiveScoreMatch: true,
        switchTeams: false,
        filterTeams: null,
        showTeamAbbr: false,
        showMatchIds: false,
        showWhistleIcon: false
    },

    groupActive: null,
    resultsTemplateHandle: null,
    fixturesHandle: null,
    feedHandle: false,
    providerName: 'vfc',
    timelineHandle: false,
    widgetType: 'resultsGroup',
    matchManager: null,
    tableRowStyles: {},

    constructor: function () {
        this.applySuper( 'constructor', arguments );

        var self = this;

        if (this.options.subscribeToLiveScoreMatch) {
            this.onPublic( 'match_selected', '_liveScoreMatchSelected' );
        }

        this.initialoptions = Object.assign({}, this.options);

        var initialRender = false;

        if (this._getProvider().options.name === 'vfcc') {
            this.defaultRowNumber = 12;
        }

        this._adjustHeight.call(this);

        this.timelineHandle = SRLive.poller.subscribe({
            providerName: this.providerName,
            feed: 'timeline',
            callback: function( timeline ) {
                // Handle round change (rerender if needed)
                if ( self.tournamentId !== timeline.tournament.id && timeline.stage === 'group' ) {
                    self.subscribeToFeed( true );
                    self.tournamentId = timeline.tournament.id;
                    return false;
                }

                if ( timeline.stage !== 'group' ) {
                    SRLive.poller.unsubscribe( self.feedHandle );
                    self.options.groupActive = false;
                    self.getFixtures();
                }
            }
        });

        this._getProvider().loadMatchManager(
            {
                widgetGroup: this.options.widgetGroup
            },
            function( component ) {
                self.matchManager = component;
            }
        );

	    this.setWidgetZoom();
        this.optionsForSetters.showGroupHeader = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showHeader = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showActiveGroupBorder = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showFlags = this.validators.assertTrue.bind(this);
        //this.optionsForSetters.subscribeToLiveScoreMatch = this.validators.assertTrue.bind(this);
        this.optionsForSetters.switchTeams = this.validators.assertTrue.bind(this);
        this.optionsForSetters.filterTeams = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showTeamAbbr = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showMatchIds = this.validators.assertTrue.bind(this);
        this.optionsForSetters.showWhistleIcon = this.validators.assertTrue.bind(this);
        this.optionsForSetters.height = this.validators.assertTrue.bind(this);
    },

    destructor: function () {
        this.applySuper( 'destructor', arguments );
        this.unsubscribeFeeds();
        if ( this.resultsTemplateHandle ) {
            SRReact.unmountComponentAtNode( this.resultsTemplateHandle.getDOMNode().parentNode );
        }
    },

    getFixtures: function ( callback ) {

        var self = this;

        SRLive.poller.request({
            providerName: this.providerName,
            feed: 'fixtures',
            callback: function ( fixturesData ) {
                var fixtures = false;

                for ( var i = 0; i < fixturesData.groupStage.length; i++ ) {
                    if ( fixturesData.groupStage[ i ].group.letter === self.options.group ) {
                        fixtures = fixturesData.groupStage[ i ];
                        break;
                    }
                }
                if ( callback ) {
                    callback( fixtures );
                } else {
                    self.render( self.options, fixtures, true );
                }


            }
        });
    },

    subscribeToFeed: function ( tournamentChanged ) {
        var self = this;

        if ( this.feedHandle ) {
            SRLive.poller.unsubscribe( this.feedHandle );
        }

        this.feedHandle = SRLive.poller.subscribe({
            providerName: this.providerName,
            feed: 'liveScore',
            callback: function ( liveScoreData ) {
                var liveScoreMatches = self._getLiveScoreResultData( liveScoreData );

                var groupActive = self._isGroupActive( liveScoreData );
                self.options.groupActive = groupActive;
                self.getFixtures( function ( fixtures ) {
                    // TODO Poglej klele k gre u render ce se rezultati napisejo
                    self.render( self.options, fixtures, tournamentChanged, liveScoreMatches );
                });

                self._getResultsData(liveScoreData);

            }
        });
    },

    /**
     * Render results.
     *
     * @return {void}
     */
    render: function ( options, data, tournamentChanged, liveScoreMatches ) {
        if (data) {
            this.data = data;
        }

        var activeMatchId = (
                                this.matchManager &&
                                this.matchManager.selectedMatch
                            ) ?
                               this.matchManager.selectedMatch.id
                            :
                                0;
        if(this.getContainer().length>0) {
            if (!this.resultsTemplateHandle) {
                this.resultsTemplateHandle = this.view.renderJsx({
                    template: 'main',
                    container: this.getContainer(),
                    doc: {
                        options: options,
                        data: data,
                        widgetType: this.widgetType,
                        liveScoreMatches: liveScoreMatches,
                        _adjustHeight: this._adjustHeight.bind(this, data),
                        activeMatchId: activeMatchId,
                        italianMarket: this.setup.italianMarket,
                        tableRowStyles: this.tableRowStyles
                    }
                });
            } else {
                this.resultsTemplateHandle.update(data, this.options.groupActive, tournamentChanged, liveScoreMatches, activeMatchId);
            }
        }

    },

    /** Feed subscription methods */

    /**
     * Makes request to fixtures feed
     * Calls render method.
     *
     * @param  {Function} callback
     * @param  {boolean}  tournamentChanged
     * @return void
     */
    _getResultsData: function ( tournamentChanged ) {
        var self = this;

        var fixturesRequest = {
            providerName: this.providerName,
            feed: 'fixtures'
        };
        var liveScoreRequest = {
            providerName: this.providerName,
            feed: 'liveScore'
        };

        SRLive.poller.compose( [ fixturesRequest, liveScoreRequest ], function( data ) {

            var groupActive = self._isGroupActive( data[ 1 ] );
            var fixtures = data[ 0 ];

            var fixturesData = false;

            for ( var i = 0; i < fixtures.groupStage.length; i++ ) {
                if ( fixtures.groupStage[ i ].group.letter === self.options.group ) {
                    fixturesData = fixtures.groupStage[ i ];
                    break;
                }
            }

            var liveScoreMatches = self._getLiveScoreResultData( data [ 1 ] );
            self.render( self.options, fixturesData, tournamentChanged, liveScoreMatches );
        });

    },

    /** Helper methods for _getResultsData */

    /**
     * Helper method, index matches from live score feed regarding to match id.
     *
     * @param  {Object} liveScoreResults
     * @return {Object}                  Object that has matches stored by match id.
     */
    _getLiveScoreResultData: function ( liveScoreResults ) {
        var liveScoreMatches = {};
        for ( var i = 0; i < liveScoreResults.matches.length; i++ ) {
            var match = liveScoreResults.matches[ i ];
            liveScoreMatches[ match.id ] = match;
        }
        return liveScoreMatches;
    },

    /**
     * Helper function, check if provided group in options is active.
     *
     * @param  {object}  liveScoreData Data returned from live score request.
     * @return {Boolean}               Returns true if provided group is active.
     */
    _isGroupActive: function ( liveScoreData ) {
        var activeGroups = {};

        if ( liveScoreData.stage === 'group' ) {
            for ( var i = 0; i < liveScoreData.matches.length; i++ ) {
                var match = liveScoreData.matches[ i ];

                if ( match && match.group.letter ) {
                    activeGroups[ match.group.letter ] = true;
                }
            }
        }

        if ( this.options.group in activeGroups ) {
            return true;
        }

        return false;
    },

    /** End of helper methods for _getResultsData */

    /** End of feed subscription methods */

    /**
     * Adjust widget height. Gets header height and calculates remaining pixels. Those are divided
     * to table rows.
     *
     * @return {void}
     */
    _adjustHeight: function (data) {
        if (!data) {
            data = this.data;
        }

        var tableRowStyles = {};

        var getStyle = function(el, style) {
            return (el) ? parseInt(window.getComputedStyle(el, null).getPropertyValue(style)) : 0;
        };

        var headerHeight =  ( this.options.showHeader ) ? ((parseInt(this.options.height) / 100) * 20) : 0;
        var remainingHeight = parseInt( this.options.height ) - ( headerHeight ) - 2;

        // default, initially set  by LJU for group mode where a matchday has 3*2 matches
        var numberOfMatches = this.defaultRowNumber || 6;
        // today this has to work for VFLM, too, so if we have data available
        // we set the number of matches from given data
        if(data && data.matches.length) {
            numberOfMatches = data.matches.length;
        }

        // How much height do we add to a single row?
        var rowHeight = Math.floor(( remainingHeight ) / numberOfMatches);

        // If divided value is not an integer, get the remainder
        var remainder = remainingHeight - ( rowHeight * numberOfMatches ) ;

        tableRowStyles.actualRowHeightEvenStyles = {
            'height' : rowHeight + 'px',
            'lineHeight' : rowHeight + 'px'
        };
        tableRowStyles.actualRowHeightOddStyles = {
            'height' : (rowHeight + 1) + 'px',
            'lineHeight' : (rowHeight + 1) + 'px'
        };
        tableRowStyles.headerContainerStyle = {
            'height': (headerHeight + remainder) + 'px'
        };

        if ( remainder > 0 ) {
            if ( headerHeight <= 0 ) {
                var tableContainer = this.getContainer().find( '.vsm-vfc-results-table-container' );
                var tableContainerHeight = tableContainer.height();

                tableRowStyles.tableContainerStyle = {
                    'height': (tableContainerHeight + remainder) + 'px'
                };
            }
        }

        this.tableRowStyles = tableRowStyles;

        if (this.resultsTemplateHandle) {
            this.resultsTemplateHandle.setProps({
                tableRowStyles: this.tableRowStyles
            });
        }

        this._getResultsData();
    },

    /**
     * Event trigger function, function triggers when a match is clicked on the livescore panel.
     *
     * @param  {object} data    Data passed on from livescore.
     * @return {void}
     */
    _liveScoreMatchSelected: function ( data ) {
        var currentChannelGroup = data && data.matchData && data.matchData.group ? data.matchData.group.letter : null;
        if ( currentChannelGroup ) {
            this.options.group = currentChannelGroup;
            this._getResultsData();
        }
    },

    /** Public API methods */

    _setHeight: function ( height ) {
        if(height) {
            this.options.height = parseInt( height ) + 'px';
            this._adjustHeight();
        }
    },

    _setGroup: function ( group ) {
        if ( this._checkGroupValidity( group ) ) {
            this.options.group = group;
            this._getResultsData();
        }
    },

    _setSubscribeToLiveScoreMatch: function( subscribeToLiveScoreMatch  ) {
        if (subscribeToLiveScoreMatch && ! this.options.subscribeToLiveScoreMatch) {
            this.onPublic( 'match_selected', '_liveScoreMatchSelected' );
        }
        else if (! subscribeToLiveScoreMatch && this.options.subscribeToLiveScoreMatch) {
            this.offPublic( 'match_selected' );
        }
        this.options.subscribeToLiveScoreMatch = subscribeToLiveScoreMatch;


    },


    setGroupAndFilterTeams: function(group, filterTeams) {
        this.options.filterTeams = filterTeams;
        this._setGroup(group);
    },


    /** End of public api methods */


    /** Helper methods */

    /**
     * Checks if the group option passed is valid.
     *
     * @param  {string} group Passed group.
     * @return {boolean}      True if valid group, false otherwise.
     */
    _checkGroupValidity: function ( group ) {
        var validGroups = [ 'A', 'B', 'C', 'D', 'E', 'F', '' ];
        if ( $.inArray( group, validGroups ) === -1 ) {
            return false;
        }
        return true;
    },

    /** End of helper methods */

    /** End public api methods */


    publicAPI: function() {
	var api = this.applySuper( 'publicAPI' );
        api.setHeight = this._setHeight.bind( this );
        api.setGroup = this._setGroup.bind( this );
        api.setSubscribeToLiveScoreMatch = this._setSubscribeToLiveScoreMatch.bind( this );
        return api;
    },

    unsubscribeFeeds: function() {
        if (this.timelineHandle) {
            SRLive.poller.unsubscribe(this.timelineHandle);
            this.timelineHandle = null;
        }
        if (this.feedHandle) {
            SRLive.poller.unsubscribe(this.feedHandle);
            this.feedHandle = null;
        }
    }
});
})(SRLive, window.SRjQuery || jQuery, window.SRjQuery || jQuery);
