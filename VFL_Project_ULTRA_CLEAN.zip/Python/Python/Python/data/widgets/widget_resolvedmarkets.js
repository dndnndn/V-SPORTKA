SRLive.widget['vswidgets.core.resolvedmarkets'] = {'setup': {"environment":"Production","dynamicallyOverwrittenUrlCategories":["directFeedUrl","playerclassCdnUrl","scoutUrl","styleUrl","feedUrl"],"useCuDoSS":true,"vfl":{"clientId":569,"clientAlias":"srvirtualgamingvfl","backdoorToken":632421,"scoutUrl":"https:\/\/vfl3mobile.aitcloud.de\/vflbb","feedUrl":"https:\/\/vfl.betradar.com\/ls\/feeds\/","platform":"","sport":"vfl","playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vbl":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":241632,"scoutUrl":"\/\/vbllive.aitcloud.de\/VS2021-02-retail-SciGaming-4digits","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vbl\/feeds\/","styleUrl":"https:\/\/vgskinnings.aitcloud.de\/vbl\/{style}\/css\/vswidgets_vbl{platform}.css","platform":"retail","sport":"vbl","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vto":{"clientId":569,"clientAlias":"srvirtualgamingvto","backdoorToken":241632,"scoutUrl":"https:\/\/vtolive.aitcloud.de\/vto","feedUrl":"https:\/\/vgls.betradar.com\/vto\/feeds\/","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vti":{"clientId":569,"clientAlias":"srvirtualgamingvti","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfec\/mobile","feedUrl":"https:\/\/vglstest.sportradar.ag\/ls\/feeds\/","platform":"","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vfc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfecshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfc{platform}.css","platform":"retail","sport":"vfec","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfnc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfncshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfnc{platform}.css","platform":"retail","sport":"vfnc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfwc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfwcshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfwc{platform}.css","platform":"retail","sport":"vfwc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vflm":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vflmshop","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vflm{platform}.css","platform":"retail","sport":"vflm","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfb":{"clientId":569,"clientAlias":"srvirtualgaming4","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfb","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfb{platform}.css","platform":"","sport":"vfb","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfas":{"clientId":569,"clientAlias":"srvirtualgamingvfas","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfas\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfas{platform}.css","platform":"","sport":"vfas","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfcc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfccshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfcc{platform}.css","platform":"retail","sport":"vfcc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"hasOwnCss":false,"jsx":{"main":["createClass({render:function(){var e=[];if(this.props.selectedResolvedMarkets)for(var t=0;t<this.props.selectedResolvedMarkets.length;t++)e.push(this.renderBadge(this.props.selectedResolvedMarkets[t]));return React.createElement(\"div\",{className:\"vsm-resolvedmarkets\"},e)},renderBadge:function(e){var t=\"\",a=\"\";return null!==e.wonOutcomeId&&(t=e.market.outcomes[e.wonOutcomeId].outcomeId,a=\": \"+e.market.outcomes[e.wonOutcomeId].name),React.createElement(\"div\",{className:\"vsm-resolvedmarkets-badge\",\"data-market\":e.market.id,\"data-outcome\":t,key:e.market.id},React.createElement(\"div\",{className:\"vsm-resolvedmarkets-badge-text\"},React.createElement(\"div\",null,e.market.name,a)),React.createElement(\"div\",{className:\"vsm-resolvedmarkets-badge-icon\"}))}})"]}}};
(function(SRLive, jQuery, $, undefined) {/* global SRReact, React, SRjQuery, SRVsmUtil */



// define it as "vswidgets.[sport].[widget]"
SRLive.w.define('vswidgets.core.resolvedmarkets', {



    // extend an existing (base)component to gain super-methods
    extend: 'vswidgets.core.basecomponent',



    // predefine values for all widget options
    // selectedMarkets: if no outcomes-array is set, all outcomes of the market are selected
    options: {
        platform: 'desktop-small',
        selectedMarkets: [
            { market: 'totalgoals/2.5', outcomes: ['o'] },
            { market: 'nextgoal/0:0', outcomes: ['1','2'] },
            { market: 'bothteamsscore', outcomes: ['yes'] }
        ],
        selectedChannel: null
    },



    // predefine reference to react template
    // to be updated via setProps()
    resolvedMarketsTemplate: null,



    // predefine reference for feed subscription
    feedSubscription: null,



    // get called initially
    constructor: function() {

        // apply super method
        this.applySuper('constructor', arguments);

        // register react template and initially render it
        // with empty props
        this.resolvedMarketsTemplate = this.view.renderJsx({
            template: 'main',
            container: this.getContainer(),
            doc: {}
        });

        // load match manager
        var self = this;
        this._getProvider().loadMatchManager({}, function(component) {
            self.matchManager = component;

            // bind setters for options
            self.optionsForSetters.selectedChannel = self.validators.assertTrue.bind(self);
            self.optionsForSetters.selectedMarkets = self.validators.assertTrue.bind(self);

            // on channelswitch
            self.onPublic('vswidgets/'+self._getSportId()+'/matchmanager/channel_switch', function() {

                // subscribe to feed
                self.subscribeFeed();

            }.bind(self));

            // free unused references
            component = null;

        });

    },



    // gets called on widget destruction
    destructor: function() {
        this.unsubscribeFeeds();

        // apply super method
        this.applySuper('destructor', arguments);

        // free unused references
        this.options = null;
        this.resolvedMarketsTemplate = null;
        this.feedSubscription = null;
        this.matchManager = null;
        this.subscribeFeed = null;
        this.publicAPI = null;
        this.getChannel = null;
        this.getChannel = null;

    },



    // subscribe to feed to get data
    // adapt data to well formatet resolvedMarkets object
    // this method could be overwritten in several providers to match to feed sets
    subscribeFeed: function() {

        // get channel
        var channel = 0;
        if(this.options.selectedChannel) {
            channel = this.options.selectedChannel;
        }else {
            channel = this.matchManager.selectedChannel;
        }

        // unsubscribe old subscription
        if(this.feedSubscription) {
            SRLive.poller.unsubscribe(this.feedSubscription);
        }

        // get feed
        var self = this;
        this.feedSubscription = SRLive.poller.subscribe({
            providerName: this.providerName,
            feed: self.setup.italianMarket ? 'italianMatchProbabilities' : 'matchProbabilities',
            args: {
                matchId: self.matchManager.getSelectedMatchForChannel(channel).id
            },
            callback: function(feedData) {
                var selectedResolvedMarkets = [];

                // filter for resolved markets
                for(var iRes=0; iRes<feedData.markets.length; iRes++) {
                    if(feedData.markets[iRes].settled) {

                        // filter for selected markets
                        for(var iSel=0; iSel<self.options.selectedMarkets.length; iSel++) {
                            if(self.options.selectedMarkets[iSel].market===feedData.markets[iRes].id) {

                                // get won outcome
                                var wonOutcomeId = null;
                                for(var iWon=0; iWon<feedData.markets[iRes].outcomes.length; iWon++) {
                                    if(feedData.markets[iRes].outcomes[iWon].status==='won') {
                                        wonOutcomeId = iWon;
                                        break;
                                    }
                                }

                                // filter for selected outcomes
                                var isOutcomeSelected = true;
                                if(self.options.selectedMarkets[iSel].outcomes) {
                                    isOutcomeSelected = false;
                                    for(var iOut=0; iOut<self.options.selectedMarkets[iSel].outcomes.length; iOut++) {
                                        if(self.options.selectedMarkets[iSel].outcomes[iOut]===feedData.markets[iRes].outcomes[wonOutcomeId].outcomeId) {
                                            isOutcomeSelected = true;
                                            break;
                                        }
                                    }
                                }
                                if(isOutcomeSelected) {

                                    // filter doubles
                                    var isDouble = false;
                                    for(var i=0; i<selectedResolvedMarkets.length; i++) {
                                        if(selectedResolvedMarkets.nameSelector===feedData.markets[iRes].id) {
                                            isDouble = true;
                                            break;
                                        }
                                    }
                                    if(!isDouble) {

                                        // add market and wonOutcomeId to the array to be rendered
                                        selectedResolvedMarkets.push({
                                            market: feedData.markets[iRes],
                                            wonOutcomeId: wonOutcomeId
                                        });

                                        break;
                                    }

                                    // free unused references
                                    isDouble = null;

                                }

                                // free unused references
                                isOutcomeSelected = null;
                                wonOutcomeId = null;

                            }
                        }

                    }
                }

                // TODO: sort for appending
                selectedResolvedMarkets.reverse();

                // render react template via setProps
                self.resolvedMarketsTemplate.setProps({
                    selectedResolvedMarkets: selectedResolvedMarkets
                });

                // free unused references
                selectedResolvedMarkets = null;

            }
        });

        // free unused references
        channel = null;

    },



    // refer publicAPI
    publicAPI: function() {
        var api = this.applySuper('publicAPI');
        api.getChannel = this.getChannel.bind(this);
        api.setChannel = this.setChannel.bind(this);
        return api;
    },



    // refer getChannel for publicAPI
    getChannel: function() {
        return this.options.selectedChannel;
    },



    // refer setChannel for publicAPI
    setChannel: function(channel) {
        this.options.selectedChannel = channel;
    },

    unsubscribeFeeds: function() {
        if(this.feedSubscription) {
            SRLive.poller.unsubscribe(this.feedSubscription);
            this.feedSubscription = null;
        }
    }

});
})(SRLive, window.SRjQuery || jQuery, window.SRjQuery || jQuery);
