SRLive.widget['vswidgets.vfc.livesettlements'] = {'setup': {"environment":"Production","dynamicallyOverwrittenUrlCategories":["directFeedUrl","playerclassCdnUrl","scoutUrl","styleUrl","feedUrl"],"useCuDoSS":true,"vfl":{"clientId":569,"clientAlias":"srvirtualgamingvfl","backdoorToken":632421,"scoutUrl":"https:\/\/vfl3mobile.aitcloud.de\/vflbb","feedUrl":"https:\/\/vfl.betradar.com\/ls\/feeds\/","platform":"","sport":"vfl","playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vbl":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":241632,"scoutUrl":"\/\/vbllive.aitcloud.de\/VS2021-02-retail-SciGaming-4digits","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vbl\/feeds\/","styleUrl":"https:\/\/vgskinnings.aitcloud.de\/vbl\/{style}\/css\/vswidgets_vbl{platform}.css","platform":"retail","sport":"vbl","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vto":{"clientId":569,"clientAlias":"srvirtualgamingvto","backdoorToken":241632,"scoutUrl":"https:\/\/vtolive.aitcloud.de\/vto","feedUrl":"https:\/\/vgls.betradar.com\/vto\/feeds\/","playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vti":{"clientId":569,"clientAlias":"srvirtualgamingvti","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfec\/mobile","feedUrl":"https:\/\/vglstest.sportradar.ag\/ls\/feeds\/","platform":"","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vgcommon.aitcloud.de\/playerclass\/stable-mobile\/"},"vfc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfecshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfc{platform}.css","platform":"retail","sport":"vfec","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfnc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfncshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfnc{platform}.css","platform":"retail","sport":"vfnc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfwc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfwcshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfwc{platform}.css","platform":"retail","sport":"vfwc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vflm":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vflmshop","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vflm{platform}.css","platform":"retail","sport":"vflm","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"vfb":{"clientId":569,"clientAlias":"srvirtualgaming4","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfb","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfb{platform}.css","platform":"","sport":"vfb","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfas":{"clientId":569,"clientAlias":"srvirtualgamingvfas","backdoorToken":632421,"scoutUrl":"https:\/\/vflive.aitcloud.de\/vfas\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfas{platform}.css","platform":"","sport":"vfas","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance"},"vfcc":{"clientId":4997,"clientAlias":"scigamingscigamingcdn","backdoorToken":632421,"scoutUrl":"\/\/vflive.aitcloud.de\/vfccshop\/mobile","directFeedUrl":"https:\/\/vfdirectdata-vs001.akamaized.net","feedUrl":"https:\/\/vgls.betradar.com\/vfl\/feeds\/","styleUrl":"https:\/\/vfskinnings.aitcloud.de\/vf\/{style}\/css\/vswidgets_vfcc{platform}.css","platform":"retail","sport":"vfcc","teamOrder":["home","away"],"playerclassCdnUrl":"https:\/\/vfcommon.aitcloud.de\/playerclass\/stable-mobile\/","thirdPlace":false,"maintenanceUrl":"https:\/\/maintenance-vs001.akamaized.net\/maintenance","style":"Scigamingcdn"},"templates":{"main":"<div class=\"vsm-livesettlement-container vsm-livesettlement-container-vfc <%= obj.numOfColumns > 1 ? 'vsm-two-column' : ''%>\"> <%if ( obj.showHeader ) { %> <div class=\"vsm-livesettlement-vfc-header\"> <div class=\"vsm-livesettlement-vfc-team-away\"> <div class=\"vsm-livesettlement-vfc-team-flag\"> <% if ( !obj.hideFlags ) { %> <img src=\"<%= obj.teamOne.thumbnail %>\"> <% }%> <\/div> <%= obj.teamOne.name %> <\/div> <div class=\"vsm-livesettlement-vfc-score\"> <% if( obj.match.displayScores ) { %> <span id=\"vsmLiveSettlementVfcOTScore\" class=\"vsm-livesettlement-vfc-score-ot\"> <% if( obj.match.displayScores.home.penalties !== '' || obj.match.displayScores.away.penalties !== '' ) { %> <div class=\"vsm-vfc-results-penalties-icon-wrap\"><span class=\"vsm-icon vsm-icon-penalty\"><\/span><\/div><%= obj.match.displayScores.home.penalties %>:<%= obj.match.displayScores.away.penalties %> <% } else if( obj.match.displayScores.home.over !== '' || obj.match.displayScores.away.over !== '' ) { %> <div class=\"vsm-vfc-results-overtime-icon-wrap\"><span class=\"vsm-icon-overtime vsm-icon\"><\/span><\/div><%= obj.match.displayScores.home.over %>:<%= obj.match.displayScores.away.over %> <% } %> <\/span> <span id=\"vsmLiveSettlementVfcFTScore\" class=\"vsm-livesettlement-vfc-score-ft\"> <%= obj.match.displayScores.home.full %>:<%= obj.match.displayScores.away.full %><\/span> <span id=\"vsmLiveSettlementVfcHTScore\" class=\"vsm-livesettlement-vfc-score-ht\"> <% if( ( obj.match.displayScores.home.half !== '' || obj.match.displayScores.away.half !== '' ) && obj.match.displayScores.home.full !== '-' ) { %> <%= obj.match.displayScores.home.half %>:<%= obj.match.displayScores.away.half %> <% } %> <\/span> <% } else { %> <span id=\"vsmLiveSettlementVfcOTScore\" class=\"vsm-livesettlement-vfc-score-ot\"> <\/span> <span id=\"vsmLiveSettlementVfcFTScore\" class=\"vsm-livesettlement-vfc-score-ft\"> -:-<\/span> <span id=\"vsmLiveSettlementVfcHTScore\" class=\"vsm-livesettlement-vfc-score-ht\"> <\/span> <% } %> <\/div> <div class=\"vsm-livesettlement-vfc-team-home\"> <%= obj.teamTwo.name %> <div class=\"vsm-livesettlement-vfc-team-flag\"> <% if ( !obj.hideFlags ) { %> <img src=\"<%= obj.teamTwo.thumbnail %>\"> <% }%> <\/div> <\/div> <\/div> <% } %> <%if ( obj.showApprovalCode ) { %> <div class=\"vsm-approval-code-container\"> <%= obj.approvalCodeLabel %> <%= obj.palAvv %><\/div> <% } %> <div class=\"vsm-livesettlement-container <%= obj.templateData.numOfCols > 1 ? 'vsm-two-column vsm-livesettlement-vfc' : 'vsm-livesettlement-vfc'%> <%= obj.hideOdds ? 'vsm-livesettlements-no-odds' : '' %>\"> <% $.each( obj.templateData.liveSettlementRows, function ( i, columnSettlementRows ) { %> <table class=\"vsm-livesettlement-vfc <%= i > 0 ? 'vsm-livesettlement-vfc-table-delimiter' : 'vsm-livesettlement-vfc-fw' %>\"> <% $.each( columnSettlementRows, function ( i, settlementRow ) { %> <tr id=\"<%= settlementRow.tableRowId %>\" class=\"<%= settlementRow.tableRowClass %>\"> <td class=\"vsm-livesettlements-market vsm-livesettlements-vfc-market vsm-livesettlements-vfc-padding <%= settlementRow.borderClass %>\"><span><%= settlementRow.nameMarket %><\/span><\/td> <td class=\"vsm-livesettlements-specialvalue vsm-livesettlements-vfc-specialvalue <%= settlementRow.borderClass %>\"><span><%= ! \/^vsm-livesettlements-row-nextgoal\/.test( settlementRow.tableRowId ) ? settlementRow.specialValue : '' %><\/span><\/td> <td class=\"vsm-livesettlements-fieldname vsm-livesettlements-vfc-fieldname <%= settlementRow.borderClass %>\"><span><%= settlementRow.fieldName %><\/span><\/td> <td class=\"vsm-livesettlements-oddvalue vsm-livesettlements-vfc-oddvalue <%= settlementRow.borderClass %>\"><span class=\"vsm-livesettlement-vfc-market-container <%= settlementRow.oddValue.length > 0 ? 'vsm-livesettlement-vfc-market-container-padded ' : '' %> <%= settlementRow.oddValue.length > 0 && settlementRow.adjustMarketContainer ? 'vsm-livesettlement-vfc-market-container-adjusted-padding' : '' %>\"><%= settlementRow.oddValue %><\/span><\/td> <\/tr> <% }); %> <\/table> <% }) %> <% if ( obj.templateData.liveSettlementRows[0].length === 0 ) { %> <div class = \"vsm-livesettlements-marketinfo\" > <span><%= view.renderText('nodata') %><\/span> <\/div> <% }%> <\/div> <\/div> "},"hasOwnCss":false,"options":{"markets":["fulltimeresult","halftimeresult","nextgoal","handicap","asianhandicap","correctscore","totalgoals","doublechance","halftime_fulltime","bothteamsscore","teamtoscore","drawnobet","oddeven","totalhometeam","totalawayteam"],"excludeMarkets":[]}}};
(function(SRLive, jQuery, $, undefined) {SRLive.w.define('vswidgets.vfc.livesettlements', {
    extend: 'vswidgets.core.livesettlements-base',

    options: {
        defaultOddValue: ''
    },

    providerName: 'vfc',
    livescoreHandle: null,
    livescoreData: null,
    timeoutHandle: null,

    teamScores: false,

    tableClass: '.vsm-livesettlement-vfc',
    headerElementClass: '.vsm-livesettlement-vfc-header',

    /**
     * overtime and penalty icon
     */
    _overtimeIcon: '<div class="vsm-vfc-results-overtime-icon-wrap">' +
    '<span class="vsm-icon-overtime vsm-icon"></span></div>',
    _penaltyIcon:  '<div class="vsm-vfc-results-penalties-icon-wrap">' +
    '<span class="vsm-icon vsm-icon-penalty"></span></div>',

    matchManager: null,

    constructor: function() {
        this.applySuper('constructor', arguments);

        // turn off this event
        this.offPublic('match_selected', 'onMatchSelected' );

        var self = this;
        this._getProvider().loadMatchManager(
            {
                widgetGroup: this.options.widgetGroup
            },
            function(component) {
                self.matchManager = component;
            }
        );

        this.onPublic( 'vswidgets/' + this._getSportId() + '/matchmanager/channel_switch', function( event ) {
            self.setChannel( event );
        }.bind(this));

        this.onPublic( 'vswidgets/' + this._getSportId() + '/matchmanager/chunk_switch', function( event ) {
            self.setChannel( event );
        }.bind(this));

        this.subscribeToLivescore();
    },

    destructor: function() {
        if (this.livescoreHandle) {
            SRLive.poller.unsubscribe(this.livescoreHandle);
        }

        if (this.liveSettlementTimelineHandle) {
            SRLive.poller.unsubscribe(this.liveSettlementTimelineHandle);
        }

        if ( this.timeoutHandle ) {
            clearTimeout(this.timeoutHandle);
            this.timeoutHandle = null;
        }

        this.applySuper('destructor', arguments);
    },

    render: function( templateData, match ) {
        this.selectedMatchId = match.id;

        var self = this;

        var teamOne = match.home, teamTwo = match.away;

        if ( this.options.switchTeams ) {
            teamOne = match.away;
            teamTwo = match.home;
        }

        var obj = {
            showApprovalCode: this.options.showApprovalCode,
            approvalCodeLabel: this.options.approvalCodeLabel,
            showHeader: this.options.showHeader,
            teamOne: teamOne,
            teamTwo: teamTwo,
            match: this.matchManager.selectedMatch,
            round: match.round,
            seasonName : this.seasonName,
            showTableHeader: this.options.showTableHeader,
            hideFlags: this.options.hideFlags,
            hideOdds: this.options.hideOdds,
            templateData: templateData
        };

        if ( SRUtil.isFunction( this._extendRenderData ) ) {
            this._extendRenderData( obj, match );
        }

        this.getContainer().html(
            self.view.render( 'main', obj )
        );

        this.setWidgetHeight();
    },

    /** Base class extension functions - used to override row rendering and adding data to render data */

    /**
     * Extend basic render data. Adds data to render object that is passed to template.
     *
     * @param  {object} obj       Render object.
     * @param  {object} matchData
     * @return {void}
     */
    _extendRenderData: function ( obj, matchData ) {
        /*var teamScores = this._extractTeamResults( matchData );

        obj = SRjQuery.extend( obj, teamScores );
        obj = SRjQuery.extend( obj, this._findOvertimeType(matchData));*/

        var avv = {
            palAvv: null
        };

        if(matchData.meta && matchData.meta.palAvv) {
            avv.palAvv = matchData.meta.palAvv;
        }
        obj = SRjQuery.extend( obj, avv );

        var maxOddValueLength = 0;

        SRjQuery.each( obj.templateData.liveSettlementRows, function ( i, columnRows ) {
            SRjQuery.each ( columnRows, function ( j, row ) {
                var oddValueStringLength = row.oddValue.length;
                if ( oddValueStringLength > maxOddValueLength ) {
                    maxOddValueLength = oddValueStringLength;
                }
                if ( j + 1 < columnRows.length ) {
                    var nextRow = obj.templateData.liveSettlementRows[ i ][ j + 1 ];
                    if ( nextRow.nameMarket.length > 0 ) {
                        obj.templateData.liveSettlementRows[ i ][ j ].borderClass = 'vsm-livesettlement-vfc-border';
                    } else {
                        obj.templateData.liveSettlementRows[ i ][ j ].borderClass = '';
                    }
                }
            });
        });

        if ( maxOddValueLength >= 5 ) {
            this._adjustMarketContainerPadding( obj );
        }

    },

    _extendSettlementRow: function ( rowObj ) {
        rowObj = SRjQuery.extend( rowObj, { 'adjustMarketContainer': false } );
    },

    /**
     * Helper method for _extendRenderData. Methods adds extra class to each row, if the odd number is greater than 10.
     * For instance if an odd value is 12.10, other containers need to be expanded so that all containers all the same.
     *
     * @param  {object} obj Render object.
     * @return {void}
     */
    _adjustMarketContainerPadding: function ( obj ) {

        SRjQuery.each( obj.templateData.liveSettlementRows, function ( i, columnRows ) {
            SRjQuery.each( columnRows, function ( j, row ) {
                var oddValueSize = row.oddValue.length;
                if ( oddValueSize <= 4 ) {
                    obj.templateData.liveSettlementRows[ i ][ j ].adjustMarketContainer = true;
                }
            });
        });

    },

    // Livescore final result updates
    subscribeToLivescore: function() {
        var self = this;
        if (this.options.showHeader) {
            this.livescoreHandle = SRLive.poller.subscribe({
                providerName: this.providerName,
                feed: 'extendedDirectLiveScores',
                callback: self.processLivescoreData.bind( self )
            });
        }
    },

    processLivescoreData: function( livescore ) {
        if( ! livescore ) {
            return;
        }
        var self = this;
        while( livescore.data ) {
            livescore = livescore.data;
        }
        self.livescoreData = livescore;
        for( var i = 0; i < Object.keys(livescore.matches).length; i++ ) {
            var matchId = Object.keys(livescore.matches)[i];
            var match = livescore.matches[matchId];
            if( match ) {
                if( self.matchesById[matchId] ) {
                    self.matchesById[matchId].displayScores = match.displayScores;
                }

                if( self.matchManager.selectedMatch && matchId == self.matchManager.selectedMatch.id ) {
                    // half
                    var halfscore = '';
                    if( (match.displayScores.home.half !== '' || match.displayScores.away.half !== '') && match.displayScores.home.full !== '-' ) {
                        halfscore = match.displayScores.home.half + ':' + match.displayScores.away.half;
                    }
                    self.getContainer().find('#vsmLiveSettlementVfcHTScore').text(
                        halfscore
                    );

                    // full
                    self.getContainer().find( '#vsmLiveSettlementVfcFTScore' ).text(
                        match.displayScores.home.full + ':' + match.displayScores.away.full
                    ).css('display','');

                    // overtime/penalties
                    var overtime = '';
                    if( (match.displayScores.home.over !== '' || match.displayScores.away.over !== '') && match.displayScores.home.penalties === '' ) {
                        overtime = self._overtimeIcon + '' + match.displayScores.home.over + ':' + match.displayScores.away.over;
                    }
                    if( (match.displayScores.home.penalties !== '' || match.displayScores.away.penalties !== '') ) {
                        overtime = self._penaltyIcon + '' + match.displayScores.home.penalties + ':' + match.displayScores.away.penalties;
                    }
                    self.getContainer().find( '#vsmLiveSettlementVfcOTScore' ).html(
                        overtime
                    );
                }
            }
        }
    },

    /**
     * Overriden base live settlement rendering functionality for VFC.
     *
     * @param  {object} row     Row to be updated (jQuery object).
     * @param  {object} rowData Row data.
     * @return {void}
     */
    _updateLiveSettlementRows: function ( row, rowData ) {
        row.find( '.vsm-livesettlements-market' ).text( rowData.nameMarket );
        row.removeClass( 'vsm-livesettlements-rownotresulted' );
        if ( ! /^vsm-livesettlements-row-nextgoal/.test( rowData.tableRowId ) ) {
            row.find( '.vsm-livesettlements-specialvalue' ).text( rowData.specialValue );
        }
        row.find( '.vsm-livesettlements-fieldname' ).text( rowData.fieldName );
        var oddValueSpan = row.find( '.vsm-livesettlements-oddvalue span' );
        if ( rowData.oddValue.length > 0 && oddValueSpan.text() === '' ) {
            oddValueSpan.text( rowData.oddValue );
            oddValueSpan.toggleClass( 'vsm-livesettlement-vfc-market-container-padded' );

            if ( ! SRjQuery( oddValueSpan ).hasClass('vsm-livesettlement-vfc-market-container-adjusted-padding') &&
                   rowData.adjustMarketContainer ) {

                oddValueSpan.addClass( 'vsm-livesettlement-vfc-market-container-adjusted-padding' );
            }
        }
        row.removeClass( 'vsm-livesettlements-spin' );
    },

    /* Overriden methods from base */

    /** Subscription functions (poller subscriptions) */

    setWidgetHeight: function() {
        /* Variable height - Define minimum height and default header margins
           in css class: "vsm-livesettlement-vfc-header"
        */

        if ( this.options.height ) {
            var getStyle = function(el, style) {
                return (el) ? parseInt(window.getComputedStyle(el, null).getPropertyValue(style).split('px')[0]) : 0;
            };

            var self = this;
            var obj = {};
            var height = (typeof this.options.height === 'number') ?
                this.options.height :
                +this.options.height.split('px')[0];
            var rows = $(this.getContainer().selector + ' ' + this.tableClass + '  tr');
            var numRows = rows.length / this.options.numOfColumns;

            // if avv shall be shown we need to adjust row height as there is more one row than expected
            if (this.options.showApprovalCode === true) {
                numRows = numRows +1;
            }
            var headerEl = self.getContainer().find('.vsm-livesettlement-vfc-header')[0];
            var headerMinHeight = getStyle(headerEl, 'min-height');
            var headerMargins = getStyle(headerEl, 'margin-top') + getStyle(headerEl, 'margin-bottom');
            var totalHeaderHeight = headerMinHeight + headerMargins;
            var maximumRowsHeight = height - totalHeaderHeight;
            var rowHeight = Math.floor(maximumRowsHeight / numRows);

            // set row height of avv container
            if (this.options.showApprovalCode === true) {
                $(self.getContainer().find('.vsm-approval-code-container')[0]).css('height', rowHeight + 'px');
            }
            var rowsHeight = rowHeight * numRows;
            var headerMarginHeight = height - rowsHeight;
            var finalHeaderHeight = headerMarginHeight - headerMargins;

            $.each(rows, function(key, val) {
                self._setRowHeight($(val), rowHeight);
            });

            $(headerEl).height(finalHeaderHeight).css('line-height', finalHeaderHeight + 'px');

            return obj;
        } else {
            return null;
        }
    },

    _setRowHeight: function ( row, rowHeight ) {
        row.css({
            'height' : rowHeight + 'px'
        });
        row.children( 'td' ).css({
            'height': rowHeight + 'px'
        });
    },

    setChannel: function ( object ) {
        // unsubscribe previous match subscription
        if ( this.liveSettlementHandle ) {
            SRLive.poller.unsubscribe( this.liveSettlementHandle );
            this.liveSettlementHandle = null;
        }

        var self = this;

        if( self.matchManager && self.matchManager.selectedMatch ) {
            var matchId = self.matchManager.selectedMatch.id;

            self.oldData = null;
            self.seasonName = self.timelineData.tournament.name;
            self.subscribeToMatchOdds( matchId );
            self.matchRunning = true;
            self.processLivescoreData( self.livescoreData );
        }
        else {
            window.setTimeout( function() { self.setChannel( object ); }, 1000 );
        }
    }
});
})(SRLive, window.SRjQuery || jQuery, window.SRjQuery || jQuery);
