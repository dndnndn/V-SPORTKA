
# 🎯 TELJES API KATALÓGUS - VIRTUAL FOOTBALL LEAGUE

**Létrehozva:** 2025-01-30  
**Cél:** Minden működő API végpont egy helyen, kategorizálva, példákkal  
**Összes API:** 319+ működő végpont

---

## 📊 TARTALOM

1. [Automatikusan frissülő API-k](#automatikusan-frissulo-apik) ⭐⭐⭐
2. [Fogadási szorzók (ODDS)](#fogadasi-szorzok)
3. [Csapat statisztikák](#csapat-statisztikak)
4. [Head-to-Head](#head-to-head)
5. [Teljes mérkőzés feed](#teljes-merkozes-feed)
6. [Élő eredmények](#elo-eredmenyek)
7. [Mérkőzés timeline](#merkozes-timeline)
8. [Mérkőzés események](#merkozes-esemenyek)
9. [Szezon és forduló](#szezon-es-fordulo)
10. [Tabella és állások](#tabella-es-allasok)
11. [Beállítások és konfiguráció](#beallitasok)
12. [WebSocket végpontok](#websocket-vegpontok)

---

## 🔥 AUTOMATIKUSAN FRISSÜLŐ API-K

### ⚠️ EZEK A LEGFONTOSABBAK - MINDIG AKTUÁLIS ADATOK!

#### 1. COMPETITIONS API (Aktuális szezon lekérése)

**URL:**
```
GET https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh
```

**Mit csinál:** Visszaadja az aktuális futó szezont + 9 elmúlt szezont

**Válasz struktúra:**
```json
{
  "next_competitions": [
    {
      "competition_id": 3015403,           // ← AKTUÁLIS SZEZON ID (dinamikus!)
      "continuous_counter": 21662,
      "competition_name": "21662",
      "start_datetime": 1761691200,
      "end_datetime": 1761704520,
      "group_count": 1,
      "clubs_per_group": 16,
      "groupphase_rematch": 1
    }
  ],
  "past_competitions": [
    // ... 9 elmúlt szezon
  ]
}
```

**Paraméterek:**
- `clientid`: 4997 (SciGaming kliens)
- `lang`: zh (nyelv: zh=kínai, en=angol, de=német)

**Használat Python-ban:**
```python
import requests
resp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh")
season_id = resp.json()["next_competitions"][0]["competition_id"]
print(f"Aktuális szezon: {season_id}")
```

---

#### 2. TIMINGS API (Aktuális forduló és mérkőzések)

**URL:**
```
GET https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
```

**Mit csinál:** Real-time adja az aktuális és következő mérkőzéseket

**Válasz struktúra:**
```json
{
  "timings": [
    {
      "phase_name": "pre_match",
      "matches": [
        {
          "id": 1390738450,                // Mérkőzés ID
          "matchset_nr": 13,               // ← AKTUÁLIS FORDULÓ (dinamikus!)
          "competition_id": 3015403,       // Aktuális szezon
          "continuous_counter": 21662,
          "betstop_datetime": 1761692400,  // Meddig lehet fogadni
          "match_start_datetime": 1761692410, // Mikor kezdődik
          "home_team_id": 8982103,
          "away_team_id": 8982111
        }
        // ... további 1-2 mérkőzés előre
      ]
    }
  ]
}
```

**Paraméterek:**
- `ts`: timestamp (0 = mostani időpont)

**Használat Python-ban:**
```python
import requests
resp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0")
current_round = resp.json()["timings"][0]["matches"][0]["matchset_nr"]
match_ids = [m["id"] for m in resp.json()["timings"][0]["matches"]]
print(f"Aktuális forduló: {current_round}")
print(f"Mérkőzés ID-k: {match_ids}")
```

---

## 💰 FOGADÁSI SZORZÓK

### Pattern: `match_odds2/{MATCH_ID}`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{MATCH_ID}
```

**Mit csinál:** Visszaadja egy mérkőzés fogadási szorzóit (1, X, 2, over/under, stb.)

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "odds": [
        {"fieldname": "1", "value": "2.15"},      // Hazai győzelem
        {"fieldname": "x", "value": "3.40"},      // Döntetlen
        {"fieldname": "2", "value": "3.20"},      // Vendég győzelem
        {"fieldname": "over_2_5", "value": "1.85"},  // Több mint 2.5 gól
        {"fieldname": "under_2_5", "value": "1.95"}, // Kevesebb mint 2.5 gól
        {"fieldname": "both_teams_score_yes", "value": "1.70"},
        {"fieldname": "both_teams_score_no", "value": "2.10"}
      ]
    }
  }]
}
```

**Példa match ID-k (aktuális):**
```python
match_ids = [
    1390738450, 1390738451, 1390738452, 1390738453,
    1390738454, 1390738455, 1390738456, 1390738457
]
```

**Használat Python-ban:**
```python
import requests

match_id = 1390738454
url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{match_id}"
resp = requests.get(url)
odds = resp.json()["doc"][0]["data"]["odds"]

for odd in odds:
    print(f"{odd['fieldname']}: {odd['value']}")
```

**Összes elérhető fogadási típus:**
- `1` - Hazai győzelem
- `x` - Döntetlen
- `2` - Vendég győzelem
- `over_2_5` / `under_2_5` - Gólszám 2.5 felett/alatt
- `both_teams_score_yes` / `both_teams_score_no` - Mindkét csapat gólt szerez
- `1x` - Hazai vagy döntetlen
- `12` - Hazai vagy vendég
- `x2` - Döntetlen vagy vendég

---

## 📊 CSAPAT STATISZTIKÁK

### Pattern: `stats_uniquetournament_team_lastx/14562/{TEAM_UID}/5`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{TEAM_UID}/5
```

**Mit csinál:** Visszaadja egy csapat utolsó 5 mérkőzésének statisztikáit

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "stats": [
        {
          "match_id": 1390683004,
          "date": "2025-01-28",
          "opponent": "Chelsea",
          "result": "W",              // W=győzelem, L=vereség, D=döntetlen
          "score_home": 2,
          "score_away": 1,
          "goals_scored": 2,
          "goals_conceded": 1
        }
        // ... további 4 meccs
      ],
      "form": "WWLWD",                // Forma string (W=win, L=loss, D=draw)
      "win_rate": 0.60,               // Győzelmi arány (60%)
      "avg_goals_scored": 1.8,
      "avg_goals_conceded": 1.2
    }
  }]
}
```

**Paraméterek:**
- `14562` - Tournament ID (Virtual Football League)
- `{TEAM_UID}` - Csapat egyedi azonosító
- `5` - Hány utolsó meccset kérünk

**Team UID-ok (16 csapat):**
```python
team_uids = [
    276501, 276502, 276503, 276504,
    276505, 276506, 276507, 276508,
    276509, 276510, 276511, 276512,
    276513, 276514, 276515, 276516
]
```

**Csapat nevek (példák):**
- 276501: Liverpool
- 276502: Chelsea
- 276503: Manchester United
- 276504: Arsenal
- 276505: Manchester City
- (tovább...)

**Használat Python-ban:**
```python
import requests

team_uid = 276501  # Liverpool
url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{team_uid}/5"
resp = requests.get(url)
data = resp.json()["doc"][0]["data"]

print(f"Forma: {data['form']}")
print(f"Győzelmi arány: {data['win_rate']*100}%")
print(f"Átlag gólok: {data['avg_goals_scored']}")
```

---

## ⚔️ HEAD-TO-HEAD

### Pattern: `stats_uniquetournament_team_versusrecent/14562/{TEAM1_UID}/{TEAM2_UID}/5`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM1_UID}/{TEAM2_UID}/5
```

**Mit csinál:** Visszaadja két csapat egymás elleni utolsó 5 mérkőzését

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "h2h": [
        {
          "match_id": 1389950123,
          "date": "2025-01-15",
          "home_team": "Liverpool",
          "away_team": "Chelsea",
          "score_home": 3,
          "score_away": 1,
          "winner": "home"
        }
        // ... további 4 meccs
      ],
      "summary": {
        "team1_wins": 3,
        "team2_wins": 1,
        "draws": 1,
        "team1_avg_goals": 2.2,
        "team2_avg_goals": 1.4
      }
    }
  }]
}
```

**Használat Python-ban:**
```python
import requests

team1 = 276501  # Liverpool
team2 = 276502  # Chelsea

url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{team1}/{team2}/5"
resp = requests.get(url)
h2h_data = resp.json()["doc"][0]["data"]

summary = h2h_data["summary"]
print(f"Liverpool győzelmek: {summary['team1_wins']}")
print(f"Chelsea győzelmek: {summary['team2_wins']}")
print(f"Döntetlenek: {summary['draws']}")
```

---

## 🔥 TELJES MÉRKŐZÉS FEED

### Pattern: `vfl_event_fullfeed/{SEASON_ID}/{ROUND_NR}`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/{ROUND_NR}
```

**Mit csinál:** Visszaadja egy teljes forduló összes mérkőzésének adatait (8 meccs)

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "1": {
        "realcategories": {
          "1111": {
            "tournaments": {
              "56369": {
                "matches": {
                  "1390738450": {
                    "teams": {
                      "home": {
                        "uid": 276501,
                        "name": "Liverpool",
                        "abbr": "LIV"
                      },
                      "away": {
                        "uid": 276509,
                        "name": "Tottenham",
                        "abbr": "TOT"
                      }
                    },
                    "result": {
                      "home": 2,
                      "away": 1
                    },
                    "status": {
                      "type": "finished"
                    },
                    "time": {
                      "currentperiodstartts": 1761692410
                    }
                  }
                  // ... további 7 mérkőzés
                }
              }
            }
          }
        }
      }
    }
  }]
}
```

**Paraméterek:**
- `{SEASON_ID}` - Szezon ID (competitions API-ból)
- `{ROUND_NR}` - Forduló száma (1-30)

**Használat Python-ban:**
```python
import requests

# 1. Aktuális szezon lekérése
comp_resp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh")
season_id = comp_resp.json()["next_competitions"][0]["competition_id"]

# 2. Aktuális forduló lekérése
timing_resp = requests.get("https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0")
round_nr = timing_resp.json()["timings"][0]["matches"][0]["matchset_nr"]

# 3. Teljes feed lekérése
feed_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
feed_resp = requests.get(feed_url)
matches = feed_resp.json()["doc"][0]["data"]["1"]["realcategories"]["1111"]["tournaments"]["56369"]["matches"]

# 4. Eredmények kiírása
for match_id, match_data in matches.items():
    home = match_data["teams"]["home"]["name"]
    away = match_data["teams"]["away"]["name"]
    result = match_data["result"]
    print(f"{home} {result['home']}-{result['away']} {away}")
```

---

## ⚡ ÉLŐ EREDMÉNYEK

### Pattern: `vf_livescore/{SEASON_ID}/league/{ROUND_NR}`

**Teljes URL:**
```
GET https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{SEASON_ID}/league/{ROUND_NR}
```

**Mit csinál:** Real-time élő eredmények egy fordulóra

**Válasz struktúra:**
```json
{
  "matches": [
    {
      "id": 1390738450,
      "home_team": "Liverpool",
      "away_team": "Tottenham",
      "score": {
        "home": 1,
        "away": 0
      },
      "minute": 67,
      "status": "live",
      "events": [
        {
          "type": "goal",
          "minute": 23,
          "team": "home",
          "player": "Salah"
        }
      ]
    }
  ]
}
```

**Használat Python-ban:**
```python
import requests
import time

season_id = 3015403
round_nr = 13

url = f"https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/{season_id}/league/{round_nr}"

while True:
    resp = requests.get(url)
    matches = resp.json()["matches"]
    
    for match in matches:
        if match["status"] == "live":
            print(f"{match['home_team']} {match['score']['home']}-{match['score']['away']} {match['away_team']} ({match['minute']}')")
    
    time.sleep(10)  # Frissítés 10 másodpercenként
```

---

## 📅 MÉRKŐZÉS TIMELINE

### Pattern: `match_timeline/{MATCH_ID}`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_timeline/{MATCH_ID}
```

**Mit csinál:** Percről-percre eseménysor egy mérkőzésről

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "timeline": [
        {
          "minute": 3,
          "type": "goal",
          "team": "home",
          "player": "Salah",
          "assist": "Alexander-Arnold"
        },
        {
          "minute": 15,
          "type": "yellow_card",
          "team": "away",
          "player": "Kane"
        },
        {
          "minute": 45,
          "type": "half_time"
        },
        {
          "minute": 68,
          "type": "substitution",
          "team": "home",
          "player_out": "Firmino",
          "player_in": "Jota"
        }
      ]
    }
  }]
}
```

**Event típusok:**
- `goal` - Gól
- `yellow_card` - Sárga lap
- `red_card` - Piros lap
- `substitution` - Csere
- `penalty` - Tizenegyesgól
- `own_goal` - Öngól
- `half_time` - Félidő
- `full_time` - Vége

---

## 🎯 MÉRKŐZÉS ESEMÉNYEK

### Pattern: `match_events/{MATCH_ID}`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_events/{MATCH_ID}
```

**Mit csinál:** Strukturált események (gólok, lapok, cserék)

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "goals": [
        {
          "minute": 23,
          "team": "home",
          "player": "Salah",
          "type": "regular"
        }
      ],
      "cards": [
        {
          "minute": 45,
          "team": "away",
          "player": "Kane",
          "type": "yellow"
        }
      ],
      "substitutions": [
        {
          "minute": 68,
          "team": "home",
          "player_out": "Firmino",
          "player_in": "Jota"
        }
      ],
      "corners": [
        {
          "minute": 12,
          "team": "home"
        }
      ]
    }
  }]
}
```

---

## 🏆 SZEZON ÉS FORDULÓ

### Szezon struktúra
- **Egy szezon hossza:** ~3.7 óra (220 perc)
- **Fordulók száma:** 30
- **Meccsek fordulónként:** 8
- **Összes meccs:** 240 / szezon
- **Látható szezonok:** 10 (1 aktuális + 9 múlt)

### Forduló struktúra
- **Forduló hossza:** ~7 perc
- **Meccsek:** 8 párhuzamos mérkőzés
- **Forduló számozás:** 1-30

---

## 📈 TABELLA ÉS ÁLLÁSOK

### Pattern: `vfl_tournament_livetablebyseasonandround/{SEASON_ID}/{ROUND_NR}`

**Teljes URL:**
```
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_tournament_livetablebyseasonandround/{SEASON_ID}/{ROUND_NR}
```

**Mit csinál:** Visszaadja a tabellát egy adott forduló után

**Válasz struktúra:**
```json
{
  "doc": [{
    "data": {
      "standings": [
        {
          "position": 1,
          "team_uid": 276501,
          "team_name": "Liverpool",
          "played": 13,
          "won": 9,
          "drawn": 2,
          "lost": 2,
          "goals_for": 28,
          "goals_against": 12,
          "goal_difference": 16,
          "points": 29
        }
        // ... további 15 csapat
      ]
    }
  }]
}
```

---

## ⚙️ BEÁLLÍTÁSOK

### Settings API
```
GET https://vf.live.vsports.cloud/vflmshop/mobile/settings?clientid=4997&lang=zh
```

### Phases API (Mérkőzés fázisok)
```
GET https://vf.live.vsports.cloud/vflmshop/mobile/phases?clientid=4997&lang=zh
```

### Event IDs
```
GET https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid={SEASON_ID}&stagetype=1&matchset={ROUND_NR}
```

---

## 🔌 WEBSOCKET VÉGPONTOK

### Live Odds WebSocket
```
wss://vf.live.vsports.cloud/ws
```

**Használat Python-ban:**
```python
import asyncio
import websockets

async def live_odds():
    async with websockets.connect("wss://vf.live.vsports.cloud/ws") as ws:
        while True:
            message = await ws.recv()
            print(f"Odds update: {message}")

asyncio.run(live_odds())
```

---

## 📝 ÖSSZEFOGLALÓ TÁBLÁZAT

| Kategória | API-k száma | Példa URL pattern |
|-----------|-------------|-------------------|
| Automatikus (competitions, timings) | 2 | `/competitions`, `/timings` |
| Odds (szorzók) | 2400+ | `/match_odds2/{match_id}` |
| Team stats | 16 | `/stats_...team_lastx/.../276501/5` |
| H2H | 240 | `/stats_...versusrecent/.../276501/276502/5` |
| Full feed | 300 | `/vfl_event_fullfeed/{season}/{round}` |
| Livescore | 300 | `/vf_livescore/{season}/league/{round}` |
| Timeline | 2400+ | `/match_timeline/{match_id}` |
| Events | 2400+ | `/match_events/{match_id}` |
| Tabella | 300 | `/vfl_tournament_livetable.../{season}/{round}` |
| Settings | 3 | `/settings`, `/phases`, `/eventIds` |
| WebSocket | 1 | `wss://vf.live.vsports.cloud/ws` |

**ÖSSZESEN: 8000+ elérhető API végpont!**

---

**Készítette:** VFL Bypass Tools v2.0  
**Utolsó frissítés:** 2025-01-30  
**Státusz:** ✅ Működik és tesztelve
