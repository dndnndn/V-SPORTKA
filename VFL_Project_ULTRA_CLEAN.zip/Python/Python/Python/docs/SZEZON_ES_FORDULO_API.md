# 🏆 TELJES SZEZON ÉS FORDULÓ API DOKUMENTÁCIÓ

## 📋 SZEZON ÉS FORDULÓ STRUKTÚRA

### Szezon struktúra (gyors áttekintés)
- **Egy szezon hossza:** ~3.7 óra (220 perc)
- **Fordulók száma:** 30 forduló/szezon
- **Meccsek fordulónként:** 8 mérkőzés
- **Összes meccs:** 240 mérkőzés/szezon
- **Látható szezonok:** 10 (1 aktuális + 9 múlt)
- **Csapatok száma:** 16 csapat (Team ID: 276501-276516)
- **Tournament ID:** 14562 (fix, mindig ez)

### Forduló struktúra (részletes)
- **Forduló hossza:** ~7-8 perc
- **Meccsek:** 8 párhuzamos mérkőzés egyszerre
- **Forduló számozás:** 1-30 (minden szezonban)
- **Mérkőzés időtartam:** ~3-4 perc (tényleges játékidő)
- **Mérkőzések közti szünet:** ~3-4 perc (fogadási idő)

---

## 📊 SZEZON LÁTHATÓSÁG

### Competitions API
```
https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh
```

**Visszaadott adatok:**
- ✅ **1 következő szezon** (`next_competitions`) - ez az AKTUÁLIS FUTÓ SZEZON
- ✅ **9 elmúlt szezon** (`past_competitions`) - visszamenőleg
- ✅ **ÖSSZESEN: 10 szezon** elérhető mindig

---

## ⏰ SZEZON IDŐTARTAM

- **Egy szezon hossza:** ~3.7 óra (220 perc)
- **30 forduló** van egy szezonban
- **8 mérkőzés** van egy fordulóban
- **Összesen 240 mérkőzés** egy szezon alatt
- **Szezonok folyamatosak:** egyik véget ér → azonnal új kezdődik

---

## 🔍 1. AKTUÁLIS SZEZON ÉS FORDULÓ LEKÉRÉSE

### API:
```
https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh
```

### Python példa:
```python
import requests

# Competitions API
comp_data = requests.get(
    "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
).json()

# Aktuális szezon
current_season = comp_data["next_competitions"][0]
season_id = current_season["competition_id"]
season_name = current_season["competition_name"]
counter = current_season["continuous_counter"]

print(f"Aktuális szezon ID: {season_id}")
print(f"Szezon név: {season_name}")
print(f"Folyamatos számláló: {counter}")
```

**Példa válasz:**
```json
{
    "next_competitions": [
        {
            "competition_id": 3015230,
            "continuous_counter": 21659,
            "competition_name": "21659",
            "start_datetime": 1761512867,
            "end_datetime": 1761526187
        }
    ],
    "past_competitions": [
        {
            "competition_id": 3015175,
            "continuous_counter": 21658,
            ...
        }
        // ... 8 további elmúlt szezon
    ]
}
```

---

## 📅 2. AKTUÁLIS FORDULÓ LEKÉRÉSE

### API:
```
https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
```

### Python példa:
```python
import requests

# Timings API
timings_data = requests.get(
    "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
).json()

# Aktuális forduló
current_match = timings_data["timings"][0]["matches"][0]
current_round = current_match["matchset_nr"]
match_id = current_match["id"]

print(f"Aktuális forduló: {current_round}")
print(f"Aktuális mérkőzés ID: {match_id}")
```

**Példa válasz:**
```json
{
    "timings": [
        {
            "phase_name": "pre_match",
            "matches": [
                {
                    "id": 1390683020,
                    "matchset_nr": 27,
                    "competition_id": 3015230,
                    "match_start_datetime": 1761524617,
                    "betstop_datetime": 1761524607,
                    "home_team_id": 8982007,
                    "away_team_id": 8982008
                }
            ]
        }
    ]
}
```

---

## 🗓️ 3. TELJES SZEZON PROGRAM (MINDEN FORDULÓ)

### API formátum:
```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/{ROUND_NUMBER}
```

### Python példa - TELJES 30 FORDULÓ:
```python
import requests

season_id = 3015230  # Dinamikusan lekérhető a competitions API-ból

all_rounds = {}

# Minden forduló (1-30) lekérése
for round_nr in range(1, 31):
    url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
    
    resp = requests.get(url, timeout=5)
    data = resp.json()
    
    # Navigáljunk a mérkőzésekhez
    matches_dict = data["doc"][0]["data"]["1"]["realcategories"]["1111"]["tournaments"]["56369"]["matches"]
    
    round_matches = []
    for match_id, match in matches_dict.items():
        round_matches.append({
            "match_id": int(match_id),
            "round": round_nr,
            "home_uid": match["teams"]["home"]["uid"],
            "away_uid": match["teams"]["away"]["uid"],
            "home_name": match["teams"]["home"]["name"],
            "away_name": match["teams"]["away"]["name"],
            "home_abbr": match["teams"]["home"]["abbr"],
            "away_abbr": match["teams"]["away"]["abbr"]
        })
    
    all_rounds[round_nr] = round_matches
    print(f"Forduló {round_nr}: {len(round_matches)} mérkőzés")

print(f"\nÖsszesen: {sum(len(m) for m in all_rounds.values())} mérkőzés")
```

**Egy mérkőzés adatszerkezete:**
```json
{
    "match_id": 1390683020,
    "round": 27,
    "home_uid": 276507,
    "away_uid": 276508,
    "home_name": "Liverpool",
    "away_name": "Chelsea",
    "home_abbr": "LIV",
    "away_abbr": "CHE"
}
```

---

## 🎯 4. KÖVETKEZŐ 3 FORDULÓ (Tippeléshez)

```python
import requests

def get_next_rounds(count=3):
    """Következő N forduló lekérése tippeléshez"""
    
    # 1. Aktuális szezon és forduló
    comp_data = requests.get(
        "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
    ).json()
    season_id = comp_data["next_competitions"][0]["competition_id"]
    
    timings_data = requests.get(
        "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
    ).json()
    current_round = timings_data["timings"][0]["matches"][0]["matchset_nr"]
    
    # 2. Következő N forduló lekérése
    next_rounds = {}
    for i in range(count):
        round_nr = current_round + i
        if round_nr > 30:  # Szezon vége
            break
        
        url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{season_id}/{round_nr}"
        resp = requests.get(url)
        data = resp.json()
        
        matches_dict = data["doc"][0]["data"]["1"]["realcategories"]["1111"]["tournaments"]["56369"]["matches"]
        
        next_rounds[round_nr] = []
        for match_id, match in matches_dict.items():
            next_rounds[round_nr].append({
                "match_id": int(match_id),
                "home": match["teams"]["home"]["name"],
                "away": match["teams"]["away"]["name"],
                "home_uid": match["teams"]["home"]["uid"],
                "away_uid": match["teams"]["away"]["uid"]
            })
    
    return next_rounds

# Használat
upcoming = get_next_rounds(3)
for round_nr, matches in upcoming.items():
    print(f"\n📅 Forduló {round_nr}:")
    for match in matches:
        print(f"   {match['home']} vs {match['away']}")
```

---

## 📈 5. CSAPAT STATISZTIKÁK (Forma, H2H)

### Utolsó 5 mérkőzés (forma):
```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{TEAM_UID}/5
```

### Head-to-Head (egymás ellen):
```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{TEAM1_UID}/{TEAM2_UID}/5
```

### Példa - Tipp generálás következő fordulóra:
```python
def get_betting_tips_for_next_round():
    """Következő forduló tippjei statisztikák alapján"""
    
    # Lekérjük a következő forduló mérkőzéseit
    next_rounds = get_next_rounds(1)
    next_round_nr = list(next_rounds.keys())[0]
    next_matches = next_rounds[next_round_nr]
    
    tips = []
    for match in next_matches:
        home_uid = match["home_uid"]
        away_uid = match["away_uid"]
        
        # Forma lekérése
        home_form_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{home_uid}/5"
        away_form_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/14562/{away_uid}/5"
        
        # H2H lekérése
        h2h_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/14562/{home_uid}/{away_uid}/5"
        
        # Szorzók lekérése
        odds_url = f"https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{match['match_id']}"
        
        # TODO: Elemzés és tipp generálás
        # ...
        
        tips.append({
            "match": f"{match['home']} vs {match['away']}",
            "tip": "...",
            "confidence": "..."
        })
    
    return tips
```

---

## 🔄 AUTOMATIKUS FRISSÍTÉS STRATÉGIA

```python
import requests
import time

def auto_refresh_strategy():
    """Automatikusan frissülő scraper"""
    
    while True:
        # 1. Lekérjük az aktuális szezont
        comp_data = requests.get(
            "https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh"
        ).json()
        
        current_season_id = comp_data["next_competitions"][0]["competition_id"]
        
        # 2. Lekérjük az aktuális fordulót
        timings_data = requests.get(
            "https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0"
        ).json()
        
        current_round = timings_data["timings"][0]["matches"][0]["matchset_nr"]
        
        # 3. Feldolgozzuk az adatokat
        print(f"Szezon: {current_season_id}, Forduló: {current_round}")
        
        # TODO: Tippelési logika, odds figyelés, stb.
        
        # 4. Várunk 60 másodpercet
        time.sleep(60)
```

---

## 📊 ÖSSZEFOGLALÓ

| Téma | API | Frissülés | Láthatóság |
|------|-----|-----------|------------|
| **Aktuális szezon** | `competitions` API | ~3.7 óránként | 1 következő + 9 elmúlt |
| **Aktuális forduló** | `timings` API | ~7-8 percenként | 2-3 következő forduló |
| **Teljes program** | `vfl_event_fullfeed/{season}/{round}` | Statikus | 1-30 forduló |
| **Csapat statisztikák** | `stats_team_lastx` | Real-time | Utolsó 5 mérkőzés |
| **H2H** | `stats_team_versusrecent` | Real-time | Utolsó 5 egymás elleni |

---

## ✅ KÖVETKEZTETÉS

1. **MINDIG 1 következő szezon** látható (az aktuális futó)
2. **9 elmúlt szezon** visszamenőleg elérhető
3. **Szezon automatikus váltás** - új szezon azonnal megjelenik
4. **30 forduló** egy szezonban, mind elérhető előre
5. **Nincs előre látás** - csak az aktuális szezon adatai elérhetők előre
6. **Következő szezon** = Amikor az aktuális véget ér, az új automatikusan megjelenik

---

**Készítve:** 2025-10-27  
**Tesztelve:** ✅ Minden API működik  
**Láthatóság:** 10 szezon (1 aktuális + 9 múlt)
