# 🎯 FOGADÁSI API VÉGPONTOK ÖSSZEFOGLALÓJA

## 📊 Összesen: 114 API végpont találva

---

## 🔥 LEGFONTOSABB API-K TIPPEK LEADÁSÁHOZ

### 1️⃣ **FOGADÁSI SZORZÓK (ODDS)** 
🎲 8 különböző mérkőzéshez (match_id: 1390683004-1390683011)

```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{MATCH_ID}
```

**Példák:**
- `match_odds2/1390683004` - 1. mérkőzés szorzók
- `match_odds2/1390683005` - 2. mérkőzés szorzók
- `match_odds2/1390683011` - 8. mérkőzés szorzók

**Mit kapsz:** Aktuális fogadási szorzók mérkőzesenként

---

### 2️⃣ **CSAPAT STATISZTIKÁK** 
📈 Utolsó 5 mérkőzés eredménye csapatonként

```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_lastx/{TOURNAMENT_ID}/{TEAM_ID}/5
```

**Példák (16 különböző csapat):**
- Team 276501, 276502, 276503... 276516
- Tournament ID: `14562`

**Mit kapsz:** Forma, győzelmek, vereségek, gólstatisztikák

---

### 3️⃣ **HEAD-TO-HEAD (EGYMÁS ELLENI MECCSEK)**
⚔️ Közvetlen összecsapások

```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/stats_uniquetournament_team_versusrecent/{TOURNAMENT_ID}/{TEAM1}/{TEAM2}/5
```

**Példák:**
- `276502 vs 276506` - Utolsó 5 egymás elleni meccs
- `276503 vs 276515`
- `276514 vs 276510`

**Mit kapsz:** Korábbi eredmények, trendek

---

### 4️⃣ **ÉLŐ EREDMÉNYEK**
⚡ Real-time match score

```
https://vfdirectdata.live.vsports.cloud//14562/scigamingscigamingcdn/zh/Europe:Berlin/vf_livescore/3015230/league/25
```

**Paraméterek:**
- Season ID: `3015230`
- League ID: `14562`
- Matchset: `25`

**Mit kapsz:** Aktuális állás, percek, gólok

---

### 5️⃣ **MÉRKŐZÉS AZONOSÍTÓK**
🆔 Összes mérkőzés ID-k lekérése

```
https://vf.live.vsports.cloud/vflmshop/mobile/eventIds.json?clientid=4997&lang=zh&seasonid=3015230&stagetype=1&matchset=25
```

**Mit kapsz:** Teljes lista az aktuális mérkőzésekről

---

### 6️⃣ **TELJES MÉRKŐZÉS ADATOK (FULL FEED)**
📋 Minden információ egy helyen

```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/3015230/25
```

**Mit kapsz:** 
- Csapatok
- Időpontok
- Eredmények
- Szorzók
- Statisztikák

---

### 7️⃣ **SPORTRADAR H2H API**
🏆 Profi statisztikák (Sportradar által)

```
https://s5.sir.sportradar.com/scigamingvirtuals/zh/1/season/%season_id%/h2h/%team1%/%team2%
```

**Használat:** Helyettesítsd be a season_id, team1, team2 értékeket

**Mit kapsz:** Részletes csapat összehasonlítás

---

### 8️⃣ **BEÁLLÍTÁSOK & IDŐZÍTÉS**
⚙️ Rendszer beállítások

```
https://vf.live.vsports.cloud/vflmshop/mobile/settings?clientid=4997&lang=zh
https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
https://vf.live.vsports.cloud/vflmshop/mobile/phases?clientid=4997&lang=zh
```

**Mit kapsz:** Mérkőzés időpontok, fázisok, beállítások

---

## 📂 API KATEGÓRIÁK

| Kategória | Darabszám | Leírás |
|-----------|-----------|---------|
| **ODDS** | 17 | Fogadási szorzók |
| **STATS** | 48 | Csapat statisztikák |
| **MATCH** | 23 | Mérkőzés adatok |
| **TEAM** | 51 | Csapat információk |
| **LIVE** | 220 | Élő adatok (streaming bele) |
| **FEED** | 71 | Adat feedek |
| **EVENT** | 7 | Esemény adatok |
| **SEASON** | 9 | Szezon információk |
| **LEAGUE** | 34 | Liga adatok |

---

## 🎓 HOGYAN HASZNÁLD TIPPEK LEADÁSÁHOZ

### Stratégia 1: Forma alapú tippelés
1. Lekéred a csapatok utolsó 5 meccsét (`stats_team_lastx`)
2. Elemzed a győzelem/vereség arányt
3. Megnézed az aktuális szorzókat (`match_odds2`)
4. Tippet adsz a forma alapján

### Stratégia 2: H2H alapú tippelés
1. Lekéred az egymás elleni meccseket (`stats_team_versusrecent`)
2. Azonosítod a trendeket (ki szokott nyerni)
3. Összeveted az aktuális szorzókkal
4. Tippet adsz a történelmi adatok alapján

### Stratégia 3: Élő fogadás
1. Figyeled az élő eredményeket (`vf_livescore`)
2. Lekéred a teljes mérkőzés adatokat (`vfl_event_fullfeed`)
3. Gyors döntést hozol a pillanatnyi állás alapján

---

## 🔧 TESZTELÉS

Használd a fájlokat:
- `betting_apis.txt` - Összes fogadási API
- `api_endpoints.txt` - Összes API végpont
- `api_details.json` - Részletes információk (JSON formátum)
- `all_network_urls.txt` - Minden talált URL

---

## 💡 FONTOS MEGJEGYZÉSEK

1. **Language parameter:** `lang=zh` (kínai) - változtatható: `en`, `de`, stb.
2. **Client ID:** `4997` - ez a SciGaming kliens
3. **Timezone:** `Europe:Berlin` - időzónát használ
4. **Season ID:** `3015230` - aktuális szezon
5. **Tournament ID:** `14562` - Virtual Football League

---

**Készült:** 2025-10-27  
**Selenium verzió:** 4.38.0  
**Hálózati forgalom figyelés:** 60 másodperc  
**Találat:** 114 fogadási API + 11 egyéb URL
