# ⚡ PROJECT CONTEXT - READ THIS FIRST!

**Generated:** 2025-11-07 10:56

---

## 🎯 WHAT IS THIS PROJECT?

**VFL Betting Analytics Platform** - Virtual Football League fogadási és analitikai platform

**Quick Stats:**
- 📊 0+ API endpoints
- 💻 0+ code examples  
- 📚 0 documentation files
- 🎲 2400+ historical matches

---

## 🚀 INSTANT START GUIDE FOR NEW AGENT

### Step 1: Understand the Basics (30 seconds)
- This is a **betting analytics** platform
- Uses **VFL (Virtual Football League) API**
- All APIs are **auto-updating** (never hardcode season/round!)
- Tournament ID: **14562** (always!)

### Step 2: Core Rules (NEVER FORGET!)
⚠️ **NEVER hardcode `season_id` or `round_nr`** - always fetch dynamically!
⚠️ Team UIDs: **276501-276516** (16 teams)
⚠️ Use `competitions` API to get current season
⚠️ Use `timings` API to get current round

### Step 3: Most Important APIs
```python
# Get current season
GET https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh

# Get current round
GET https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0

# Get match odds
GET https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/match_odds2/{MATCH_ID}
```

---

## 📂 WHERE TO FIND THINGS

**For quick API reference:**
→ `Python/Python/Python/docs/MUKODO_API_LINKEK.md` - All working APIs

**For code examples:**
→ `Python/Python/Python/docs/TELJES_LOGIKA_GYUJTEMENY.md` - Complete logic examples

**For season/round structure:**
→ `Python/Python/Python/docs/SZEZON_ES_FORDULO_API.md` - How seasons work

**For detailed info:**
→ `AGENT_ONBOARDING_HU.md` - Full Hungarian documentation
→ `AGENT_ONBOARDING.md` - Full English documentation

---

## 💡 COMMON USER REQUESTS (WHAT TO DO)

**"Generate betting tips"**
→ Use `stats_uniquetournament_team_lastx` for team form
→ Use `stats_uniquetournament_team_versusrecent` for H2H stats

**"Monitor live odds"**
→ Use `match_odds2` API with polling

**"Analyze team performance"**
→ Use team statistics APIs (see MUKODO_API_LINKEK.md)

**"Download historical data"**
→ Loop through seasons & rounds using full feed API

---

## 🔄 CONTINUATION FROM PREVIOUS SESSION

**Check these files for context:**
1. `HANDOFF_PAYLOAD.json` - What was done in last session
2. `TASK_LIST.json` - Pending tasks (if exists)
3. `PROJECT_STATE.json` - Current project status
4. `PROJECT_CHANGELOG.md` - All changes history

---

## ⚡ TOKEN OPTIMIZATION TIP

**Don't read everything at once!** Use lazy loading:
- Read THIS file first (you're doing it!) ✅
- Ask user what they want
- THEN read specific docs for that task
- Use `grep` to search instead of reading full files

**This saves ~90% of tokens!** 🎉

---

## ✅ YOU'RE READY!

You now know enough to start helping the user!

**Next steps:**
1. ✅ Read HANDOFF_PAYLOAD.json (if exists) 
2. ✅ Ask user: "What do you want to build?"
3. ✅ Use documentation as needed (don't read all at once!)

**Let's build something amazing!** 🚀
