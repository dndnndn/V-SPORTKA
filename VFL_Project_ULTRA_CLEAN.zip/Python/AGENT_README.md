# 🎯 REPLIT AGENT - START HERE!

**👋 Hello Replit Agent!**

Welcome to the **VFL Betting Analytics Platform**. This README contains everything you need to know.

---

## ⚡ NEW in v2.0: ULTRA-FAST ONBOARDING!

**🚀 For INSTANT context (saves 90% tokens):**
→ Read `PROJECT_CONTEXT.md` first! (30 seconds)
→ Then come back here for details

**🔄 Continuing from previous session?**
→ Read `HANDOFF_PAYLOAD.json` to see what was done
→ Check `TASK_LIST.json` for pending work

---

## 📊 PROJECT QUICK FACTS

- **Platform:** Virtual Football League (VFL) Betting & Analytics
- **Total API Endpoints:** 0+
- **Code Examples:** 0+
- **Documentation Files:** 0
- **Historical Data:** 2400+ matches (10 seasons × 30 rounds × 8 matches)

---

## 🚀 WHAT YOU NEED TO KNOW

### 1. **This project is FULLY DOCUMENTED**

All the detailed information is in these files:

📖 **English Documentation:** `AGENT_ONBOARDING.md`  
📖 **Magyar Dokumentáció:** `AGENT_ONBOARDING_HU.md`

### 2. **Key Documentation Files** (in `Python/Python/Python/docs/`)



### 3. **Most Important APIs** (Auto-Updating!)

**Get Current Season:**
```
https://vf.live.vsports.cloud/vflmshop/mobile/competitions?clientid=4997&lang=zh
```

**Get Current Round:**
```
https://vf.live.vsports.cloud/vflmshop/mobile/timings?&ts=0
```

**Get Full Round Data:**
```
https://vgls.live.vsports.cloud/vfl/feeds/?/scigamingscigamingcdn/zh/Europe:Berlin/gismo/vfl_event_fullfeed/{SEASON_ID}/{ROUND_NR}
```

### 4. **Critical Rules**

⚠️ **NEVER hardcode `season_id` or `round_nr`** - always fetch dynamically!  
⚠️ **Tournament ID is always:** `14562`  
⚠️ **Tournament ID in full feed:** `56369`  
⚠️ **Team UIDs:** `276501` - `276516` (16 teams)

---

## 🎯 COMMON USER REQUESTS

When users ask you to:

1. **"Generate betting tips"**
   - Read: `AGENT_ONBOARDING.md` → Section "Code Examples"
   - Use: `stats_uniquetournament_team_lastx` for team form
   - Use: `stats_uniquetournament_team_versusrecent` for H2H

2. **"Monitor live odds"**
   - Use: `match_odds2` API with polling

3. **"Analyze team performance"**
   - Use: Team statistics APIs from documentation

4. **"Download historical data"**
   - Loop through seasons & rounds using full feed

---

## 📦 DEPENDENCIES

This project uses:
- **Python 3.11+**
- **requests** library (auto-installed by Replit)

---

## 📖 DOCUMENTATION MAP (What to Read When)

**When user asks about:**

- **"How to get current season/round?"** → Read `AUTOMATIKUS_AKTUALIS_API.md`
- **"Show me all API endpoints"** → Read `MUKODO_API_LINKEK.md`
- **"How to build a betting bot?"** → Read `TELJES_LOGIKA_GYUJTEMENY.md`
- **"Season structure?"** → Read `SZEZON_ES_FORDULO_API.md`
- **"Complete API reference?"** → Read `TELJES_API_DOKUMENTACIO.md` or `TELJES_API_KATALOGUS.md`

**File locations:** All in `Python/Python/Python/docs/`

---

## ✅ YOUR WORKFLOW AS AGENT

### 🆕 Enhanced v2.0 Workflow:

1. ✅ **Read PROJECT_CONTEXT.md first** (instant overview, saves 90% tokens!)
2. ✅ **Check HANDOFF_PAYLOAD.json** (if continuing from previous session)
3. ✅ **Check TASK_LIST.json** (for any pending work)
4. ✅ **Read this README** (you're doing it!)
5. ✅ **Use lazy loading** - only read specific docs when needed
6. ✅ **Always fetch dynamic season/round** - never hardcode
7. ✅ **Use code examples** as templates from docs

---

## 🎉 YOU'RE READY!

You now have **COMPLETE CONTEXT** without using many tokens!

When the user asks for help, you know:
- ✅ All 0+ API endpoints
- ✅ All 0+ code examples
- ✅ Complete project structure
- ✅ Best practices & patterns
- ✅ Previous session context (if any)

**Start helping the user build amazing betting tools!** 🚀

